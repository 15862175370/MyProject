package com.friendtimes.payment.utils;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.friendtime.foundation.utils.Utility;
import com.friendtimes.payment.model.entity.RechargeCard;
import com.friendtimes.payment.model.entity.RechargeCardDetailData;
import com.friendtimes.payment.ui.view.impl.PayRechargeCardView;
import com.friendtimes.payment.ui.view.impl.PayRechargeCardViewNext;
import com.friendtimes.payment.widget.dialog.BJMSdkDialog;

import java.util.ArrayList;


/**
 * 对话框工具类 ，调用时只需 DialogUtil.
 *
 * @author Administrator
 */
public class Pay_Sdk_DialogUtil {

    private static final String TAG = Pay_Sdk_DialogUtil.class.getSimpleName();
    //当前选择的运营商数据
    public static RechargeCardDetailData currentRechargeCardDetailData = null;

   // private static ft_paymentDialog ftDialog;

    // 充值卡名称
    private static String[] cardsName = null;

    // 某种充值卡的所有面额
    private static ArrayList<Integer> denominationList = null;
    //最终选定的充值卡类型
    public static RechargeCard rechargeCard = null;

    protected static Dialog mProgressDialog;

    public static RechargeCardDetailData currentRechargeCardDetailData() {

        return currentRechargeCardDetailData;

    }

    public static RechargeCard currentRechargeCard() {

        return rechargeCard;

    }




    /**
     * 创建一个透明进度条dialog
     *
     * @param context
     * @param message
     * @return
     */

    public static final Dialog createTransparentProgressDialog(Context context, String message) {
        Dialog dialog = new Dialog(context);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        LinearLayout viewGroup = new LinearLayout(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                  ViewGroup.LayoutParams.WRAP_CONTENT);
        viewGroup.setBackgroundColor(0x10000000);
        viewGroup.setLayoutParams(params);
        viewGroup.setPadding(10, 10, 20, 10);
        viewGroup.setOrientation(LinearLayout.HORIZONTAL);
        ProgressBar bar = new ProgressBar(context);
        TextView msgText = new TextView(context);
        msgText.setTextColor(Color.WHITE);
        msgText.setText(message);
        msgText.setGravity(Gravity.CENTER_VERTICAL);
        viewGroup.addView(bar, params);
        params.height = ViewGroup.LayoutParams.FILL_PARENT;
        params.leftMargin = 10;
        viewGroup.addView(msgText, params);
        dialog.setContentView(viewGroup);
        dialog.setCancelable(false);
        return dialog;
    }

    /**
     * 充值卡选择运营商选择对话框
     *
     * @param context               上下文
     * @param operatorsName         运营商名字
     * @param chooseOperatorsBtn    选择运营商按钮
     * @param list                  充值卡信息数据类
     * @param chooseRechargeCardBtn 选择充值卡
     */
   public static AlertDialog showRechargeCardDialog(Context context,
                                                     final String[] operatorsName, final Button chooseOperatorsBtn,
                                                     final ArrayList<RechargeCardDetailData> list,
                                                     final Button chooseRechargeCardBtn, final PayRechargeCardView rechargeCardView) {
        AlertDialog dialog = new AlertDialog.Builder(context)
                  .setTitle(
                            Utility.getString(Resource.string.ft_payment_sdk_dock_recharge_cardPay_choose_operators_str,context))
                  .setItems(operatorsName, new DialogInterface.OnClickListener() {

                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          chooseOperatorsBtn.setText(operatorsName[which]);
                          chooseOperatorsBtn.setTag(which);
                          for (int i = 0; i < list.size(); i++) {
                              if ((operatorsName[which]).equals(list.get(i).tip)) {
                                  currentRechargeCardDetailData = list.get(i);
                                  // 显示默认选中的卡类型的所有面额
                                  chooseRechargeCardBtn.setText(currentRechargeCardDetailData.ct.get(0).name);
                                  denominationList = currentRechargeCardDetailData.ct.get(0).rule;
                                  rechargeCard = currentRechargeCardDetailData.ct.get(0);
                                  rechargeCardView.showCardPriceList(denominationList);
                                  cardsName = new String[currentRechargeCardDetailData.ct.size()];

                                  for (int j = 0; j < currentRechargeCardDetailData.ct.size(); j++) {
                                      cardsName[j] = currentRechargeCardDetailData.ct.get(j).name;
                                  }
                                  break;
                              }
                          }
                      }
                  }).show();
        return dialog;

    }

    /**
     * 充值卡选择充值卡对话框
     *
     * @param context               上下文
     * @param chooseRechargeCardBtn 选择充值卡按钮
     * @return
     */
    public static AlertDialog showRechargeCardName(Context context, final Button chooseRechargeCardBtn, final PayRechargeCardView rechargeCardView) {

        AlertDialog cardNamedialog = new AlertDialog.Builder(context)
                  .setTitle(Utility.getString(Resource.string.ft_payment_sdk_dock_recharge_cardPay_choose_cardtype_str,context))
                  .setItems(cardsName, new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dia, int which) {
                          if (cardsName == null
                                    || cardsName.length == 0
                                    || currentRechargeCardDetailData == null) {
                              return;
                          }
                          chooseRechargeCardBtn.setText(cardsName[which]);
                          for (int i = 0; i < currentRechargeCardDetailData.ct.size(); i++) {
                              if (cardsName[which]
                                        .equals(currentRechargeCardDetailData.ct.get(i).name)) {
                                  denominationList = currentRechargeCardDetailData.ct.get(i).rule;
                                  rechargeCard = currentRechargeCardDetailData.ct.get(i);
                                  rechargeCardView.showCardPriceList(denominationList);
                                  break;
                              }
                          }
                      }
                  }).show();

        return cardNamedialog;

    }


    /**
     * 充值后提示语对话框
     *
     * @param msg                     充值提示语
     * @param context                 上下文
     * @param payRechargeCardViewNext payRechargeCardViewNext界面
     */
   public static void showDialog(String msg, Context context,final PayRechargeCardViewNext payRechargeCardViewNext) {
        final BJMSdkDialog dialog = new BJMSdkDialog(context);
        dialog.setTitle(Utility.getString(Resource.string.ft_payment_sdk_dock_pay_center_dialog_title_str,context));
        dialog.setMessage(msg);
        dialog.setPositiveButton(Utility.getString(Resource.string.ft_payment_sdk_dock_dialog_btn_ok_str,context), new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                payRechargeCardViewNext.quit();
            }
        });
        dialog.show();
    }




}
