package com.friendtimes.payment.utils;

import android.content.Context;
import android.text.TextUtils;

import com.friendtime.foundation.bean.AppInfoData;
import com.friendtime.foundation.config.NetWorkEnvConstants;
import com.friendtime.foundation.utils.SpUtil;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.http.HttpUtility;
import com.friendtimes.payment.config.PaySysConstant;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by wutao on 2015/12/28. 存储APP CDN 域名 和 URL 信息
 */
public class DomainUtility {

    private final String TAG = DomainUtility.class.getSimpleName();
    String domainJsonStr;

    private static DomainUtility domainUtility;

    private DomainUtility() {
    }

    public static DomainUtility getInstance() {
        if (domainUtility == null) {
            synchronized (HttpUtility.class) {
                if (domainUtility == null) {
                    domainUtility = new DomainUtility();
                }
            }
        }
        return domainUtility;
    }

    /**
     * 读取配置文件 json 对象
     *
     * @param context
     * @return
     */
    private JSONObject getDomainJsonStr(Context context) {
        JSONObject jsonObject = null;
        domainJsonStr = SpUtil.getStringValue(context, PaySysConstant.CDN_JSON_FILE_NAME, "");
        if (!domainJsonStr.equals("")) {
            try {
                jsonObject = new JSONObject(domainJsonStr);
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return jsonObject;
    }

    /**
     * 读取基本API domain 主要用在
     *
     * @param context
     * @return
     */
    public String getServiceSDKDomain(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return (AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? PaySysConstant.netHeadForHttps : PaySysConstant.netHeadForHttp) + jsonObject.getString("service_sdk_domain");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 读取IM API domain 主要用在 未读消息
     *
     * @param context
     * @return
     */
    public String getServiceIMDomain(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return (AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? PaySysConstant.netHeadForHttps : PaySysConstant.netHeadForHttp) + jsonObject.getString("service_im_domain");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 读取客服 API domain 主要用在
     *
     * @param context
     * @return
     */
    public String getCustomeServiceDomain(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return (AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? PaySysConstant.netHeadForHttps : PaySysConstant.netHeadForHttp) + jsonObject.getString("service_custom_domain");

            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 主要用在 读取用户中心相关 API domain
     *
     * @param context
     * @return
     */
    public String getUserCenterDomain(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return (AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? PaySysConstant.netHeadForHttps : PaySysConstant.netHeadForHttp) + jsonObject.getString("service_ucenter_domain");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 主要用在 读取上传请求相关 API domain
     *
     * @param context
     * @return
     */
    public String getUploadDomain(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return (AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? PaySysConstant.netHeadForHttps : PaySysConstant.netHeadForHttp) + jsonObject.getString("service_upload_domain");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 主要用在 读取图片存储请求 API domain
     *
     * @param context
     * @return
     */
    public String getImageResDomain(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return (AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? PaySysConstant.netHeadForHttps : PaySysConstant.netHeadForHttp) + jsonObject.getString("s_cdn_domain");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 主要用在 读取FAQ问题请求 API domain
     *
     * @param context
     * @return
     */
    public String getFAQDomain(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {

                String resultStr = (AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? replaceRquestStrProyHeader(jsonObject.getString("faq_url")) : jsonObject.getString("faq_url"));
                if (resultStr != null) return resultStr;
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 主要用在 读取FAQ 版本号
     *
     * @param context
     * @return
     */
    public String getFAQVersion(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("faq_ver");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 获取短信充值notice的参数值
     *
     * @param context
     * @return
     */
    public String getSmsNotice(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("sms_notice");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 获取一键注册、登录notice的参数值
     *
     * @param context
     * @return
     */
    public String getOneKeyNotice(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("onekey_notice");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 获取一键登录开关
     * 1 - 一键登录
     * 0 - 验证码登录
     *
     * @param context
     * @return
     */
    public String getOneKeyShowFlag(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("onekey_show_flag");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "0";
    }

    /**
     * 获取短信通道channel
     *
     * @param context
     * @return
     */
    public String getSmsChannel(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("sms_channel");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 主要用在 读取好玩友应用的包名
     *
     * @param context
     * @return
     */
    public String getHwyPackageName(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("platform_check_name");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 主要用在 读取好玩友应用下载的地址url
     *
     * @param context
     * @return
     */
    public String getHwyAppDownloadUrl(Context context) {

        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {

                String resultStr = AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? replaceRquestStrProyHeader(jsonObject.getString("platform_download_url")) : jsonObject
                        .getString("platform_download_url");
                if (resultStr != null) return resultStr;
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 获取充值卡URL
     *
     * @param context
     * @return
     */
    public String getRechargCardUrl(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                String resultStr = AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? replaceRquestStrProyHeader(jsonObject.getString("recharge_card_des_url")) : jsonObject
                        .getString("recharge_card_des_url");
                if (resultStr != null) return resultStr;

            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 获取充值卡版本号
     *
     * @return
     */
    public String getRechargCardVersion(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("recharge_card_des_ver");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 获取请求礼包功能的url地址
     *
     * @param context
     * @return
     */
    public String getAdProductUrl(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                String resultStr = AppInfoData.getNetWorkEnvConstants() == NetWorkEnvConstants.HTTPS ? replaceRquestStrProyHeader(jsonObject.getString("ad_product_url")) : jsonObject.getString
                        ("ad_product_url");
                if (resultStr != null) return resultStr;
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";

    }

    /**
     * 获取请求礼包功能的Key
     *
     * @param context
     * @return
     */
    public String getAdProductId(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("ad_product_ids");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";

    }

    /**
     * 将http 替换成https 协议
     *
     * @param resultStr
     * @return
     */
    public String replaceRquestStrProyHeader(String resultStr) {
        if (TextUtils.isEmpty(resultStr)) return null;
        StringBuilder stringBuilder = new StringBuilder(resultStr);
        stringBuilder.insert(4, "s");
        return stringBuilder.toString();
    }

    /**
     * 手机登陆时，是否开启上行短信
     * 获取手机登陆开关，目前主要分为 上行短信 和下行短信，默认 为 上行短信
     * 废弃
     *
     * @param context
     * @return
     */
    public boolean isUpSmsStartForPhoneLogin(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                String result = jsonObject.getString("phone_login_types");
                return TextUtils.isEmpty(result);
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return false;

    }

    /**
     * 账号密码规则之开关
     *
     * @param context
     * @return
     */
    public String getAccountAndPasswordRule(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("pp_rule_types");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 0:关闭
     * 1:开启
     *
     * @param context
     * @return
     */
    public boolean isUseMobileKeyLogin(Context context) {
//        return true;
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            String mobileKeyLogin = jsonObject.optString("mobile_key_login");
            return !"0".equals(mobileKeyLogin);
        }
        return false;
    }

    /**
     * 忘记密码申诉页
     *
     * @param context
     * @return
     */
    public String getCustomUrl(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("customer_url");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 实名认证规则
     *
     * @param context
     * @return
     */
    public String getCertificationSettingRule(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("certification_setting_rule");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 0:通过浏览器下载
     * 1:通过内嵌下载
     * 内嵌下载有问题，暂用浏览器下载
     *
     * @param context
     * @return
     */
    public String getUpdateMode(Context context) {
//        JSONObject jsonObject = getDomainJsonStr(context);
//        if (jsonObject != null) {
//            try {
//                return jsonObject.getString("update_mode");
//            } catch (JSONException e) {
//                e.printStackTrace();
//                LogProxy.e(TAG, e.getMessage());
//            }
//        }
        return "0";
    }

    /**
     * 福利页，游戏ID列表
     *
     * @param context
     * @return
     */
    public String getBenefitProductIds(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("benefit_product_ids");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 福利页，默认页的地址
     *
     * @param context
     * @return
     */
    public String getBenefitDefaultUrl(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("benefit_default_url");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }


    /**
     * 福利页，接口地址
     *
     * @param context
     * @return
     */
    public String getBenefitDomain(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("benefit_domain");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 福利页，icon 类型
     *
     * @param context
     * @return
     */
    public String getBenefitIconType(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("benefit_type");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

    /**
     * 获取充值限额开关
     * 0 - 关闭
     * 1 - 开启
     *
     * @param context
     * @return
     */
    public String getChargeWarnDialogRuleMode(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("recharge_warn_dialog_rule");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "0";
    }

    /**
     * 获取注册是否勾选用户协议
     * 0 - 勾选
     * 1 - 不勾选
     * @param context
     * @return
     */
    public String getRegisterAgreePro(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("register_pro_flag");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "0";
    }

    /**
     * 获取是否在主界面显示游客试玩
     * 0 - 不显示
     * 1 - 显示
     * 默认不显示
     *
     * @param context
     * @return
     */
    public String getIfShowTryUserInHome(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("show_try_in_home");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "0";
    }

    /**
     * 福利页2.0，默认页的地址
     *
     * @param context
     * @return
     */
    public String getBenefitDefaultUrl2(Context context) {
        JSONObject jsonObject = getDomainJsonStr(context);
        if (jsonObject != null) {
            try {
                return jsonObject.getString("benefit_default_url2");
            } catch (JSONException e) {
                e.printStackTrace();
                LogProxy.e(TAG, e.getMessage());
            }
        }
        return "";
    }

}
