package com.friendtimes.payment.config;

/**
 * Created by liwei002 on 2016/6/30.
 */
public class ErrorCode {
    public static  final int ERROR_CODE_SUCCESS = 0;// 标识成功
    public static final int ERROR_CODE_RECHARGECARDRESULTCODE_SUCCESS = 11012;//标示支付操作受理成功
    public static final int ERROR_CODE_RECHARGECARDRESULTCODE_ERROR = 11013;//支付操作拒绝受理
	public static final int ERROR_CODE_RECHARGECARDRESULTCODE_ORDERNUMBER_REPEAT_ERROR = 11021;//充值卡支付订单号重复
    public static final int ERROR_CODE_PAYORDERCODE = 11016;
}
