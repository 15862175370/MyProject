package com.friendtimes.payment.model.entity;

/**
 * 用于sdk服务器端生成充值订单的数据类
 * @author wutao
 *
 */
public class PayOrderData {

	//订单号
	private String orderSerial;
	//产品ID
	private String productId;
	//产品名称
	private String productName;
	//产品实际充值数量
	private int count;
	//当前应用的订单金额(元)(不可为空)
	private double money;
	private String serverId;
	//角色ID
	private String roleId;
	//平台应用充值回调（发货）地址(如果不填，默认平台后台配置的发货地址)
	private String rechargeUrl;
	// 充入用户uid(可为空，空表示给自己充值)
	private String userID = "";
	//平台应用充值透传参数(原值返回给平台应用，可以是厂家的账号标识或者服务器ID之类)
	private String ext = "";
	//其他扩展信息(可以为空，比如充值卡支付，extend存放页面填写的卡信息)
	private String extend = "";
	//订单类型(不能为空)【1 - 正常充值平台币; 2 - 充值并消费平台币(手游)】
	private String otherExtend = "";
	//需要支付订单金额(元)(不能为空)
	private double cash;
   private String smsRechargeChannel;

	public String getSmsRechargeChannel() {
		return smsRechargeChannel;
	}

	public void setSmsRechargeChannel(String smsRechargeChannel) {
		this.smsRechargeChannel = smsRechargeChannel;
	}

	public double getCash() {
		return cash;
	}

	public void setCash(double cash) {
		this.cash = cash;
	}

	public String getPayID() {
		return payID;
	}

	public void setPayID(String payID) {
		this.payID = payID;
	}

	//可获得虚拟币数量(不能为空)
	private int amount = 0;
	//支付平台ID(不可为空)【115 - 支付宝无线快捷支付】
	private String payID = "";

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getExt() {
		return ext;
	}
	public void setExt(String ext) {
		this.ext = ext;
	}
	public String getExtend() {
		return extend;
	}
	public void setExtend(String extend) {
		this.extend = extend;
	}
	public String getOtherExtend() {
		return otherExtend;
	}


	public void setOtherExtend(String otherExtend) {
		this.otherExtend = otherExtend;
	}

	public String getOrderSerial() {
		return orderSerial;
	}

	public void setOrderSerial(String orderSerial) {
		this.orderSerial = orderSerial;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public PayOrderData(String orderSerial,String productId,String productName,int count,double money,String serverId,String roleId,String rechargeUrl,String userID,String ext,String extend,String otherExtend,String smsRechargeChannel) {
		this.orderSerial = orderSerial;
		this.productId = productId;
		this.productName = productName;
		this.count = count;
		this.money = money;
		this.serverId = serverId;
		this.roleId = roleId;
		this.rechargeUrl = rechargeUrl;
		this.userID = userID;
		this.ext = ext;
		this.extend = extend;
		this.otherExtend = otherExtend;
		this.smsRechargeChannel = smsRechargeChannel;

	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public String getServerId() {
		return serverId;
	}

	public void setServerId(String serverId) {
		this.serverId = serverId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRechargeUrl() {
		return rechargeUrl;
	}

	public void setRechargeUrl(String rechargeUrl) {
		this.rechargeUrl = rechargeUrl;
	}
}
