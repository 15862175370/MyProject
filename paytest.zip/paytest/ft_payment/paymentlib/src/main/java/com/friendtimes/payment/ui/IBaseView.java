package com.friendtimes.payment.ui;

/**
 * Created by yuanwenming on 2018/1/26.
 */

public interface IBaseView {
    /**
     * 显示错误信息
     * @param message 信息
     */
    void showError(String message,int errorCode);

    /**
     * 操作成功需要的操作
     */
    void showSuccess();

}
