package com.friendtimes.payment.config;

/**
 * Created by wutao on 2017/1/10.
 *
 * 平台环境枚举类，目前主要分为 好玩友APP 平台  和 SDK
 */

public enum EveConfig {
    HWYAPP,SDK;
}
