package com.friendtimes.payment.event;

/**
 * 支付回调接口
 */
public interface FtPaymentCallback {

     void onPayCallback(int eventId);

}
