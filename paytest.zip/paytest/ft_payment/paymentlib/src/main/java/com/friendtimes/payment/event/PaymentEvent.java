package com.friendtimes.payment.event;

/**
 * Created by wutao on 2016/10/19.
 */

public class PaymentEvent {


    private int eventId;

    public PaymentEvent(int eventId) {
        this.eventId = eventId;
    }

    public int getEventId() {
        return eventId;
    }

    /**
     * 支付宝
     */
    public static final int ALIPAY_SUCCESS = 1001; //支付成功
    public static final int ALIPAY_FAIL = 1002;//支付失败
    /**
     * 微信
     */
    public static final int WXPAY_SUCCESS = 2001; //支付成功
    public static final int WXPAY_FAIL = 2002;//支付失败
    public static final int WXPAY_CANCEL = 2003; //支付成功
    /**
     * 银联
     */
    public static final int UNIONPAY_SUCCESS = 30001; //支付成功
    public static final int UNIONPAY_FAIL = 3002;//支付失败

    /**
     * 充值卡
     */
    public static final int RECHARGE_CARD_PAY_SUCCESS = 4001; //支付成功
    public static final int RECHARGE_CARD_PAY_FAIL = 4002;//支付失败

    /**
     * 短信
     */
    public static final int SMS_PAY_SUCCESS = 5001; //支付成功
    public static final int SMS_PAY_FAIL = 5002;//支付失败


}
