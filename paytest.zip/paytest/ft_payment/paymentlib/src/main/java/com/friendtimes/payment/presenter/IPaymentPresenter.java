package com.friendtimes.payment.presenter;

import android.content.Context;

import com.friendtimes.payment.model.entity.PayOrderData;


/**
 * Created by wutao on 2016/1/22.
 * 支付相关业务操作相关 视图控制器 接口
 */
public interface IPaymentPresenter {
	/**
	 * 请求U币查询
	 * 
	 * @param context 上下文
	 */
	void requestUBalance(Context context);
	/**
	 * 提交订单
	 * @param context 上下文
	 * @param payOrderData 支付信息数据类
	 */
	void submitOrder(Context context, PayOrderData payOrderData);
	/**
	 * 支付U币 
	 * @param context 上下文
	 * @param payOrderData 支付信息类
	 */
	void  requestPay(Context context, PayOrderData payOrderData);
	
	/**
	 * 短信支付
	 * @param context
	 * @param payOrderData
	 */
	void startSmsPay(Context context, PayOrderData payOrderData);

	/**
	 * 充值卡
	 * @param context
	 */
	void getRechargeCardDes(Context context);




}
