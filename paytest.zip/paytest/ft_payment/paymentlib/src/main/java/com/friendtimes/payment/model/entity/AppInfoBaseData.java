package com.friendtimes.payment.model.entity;

/**
 * Created by liwei002 on 2017/9/15.
 */

public class AppInfoBaseData {
	private String uid;
	private String token;
	private String appKey;
	private String appId;
	private String platformId;
	private String uuid;
	private String channel;
	private String version;
	private String appSecret;
	private int screenOrientation;
	private String appName;
	private String passPort;
	private String mobile;
	private boolean isBindMobile = false;
	private boolean isOpenSmsPay = true;

	public boolean isBindMobile() {
		return isBindMobile;
	}

	public void setBindMobile(boolean bindMobile) {
		isBindMobile = bindMobile;
	}

	public boolean isOpenSmsPay() {
		return isOpenSmsPay;
	}

	public void setOpenSmsPay(boolean openSmsPay) {
		isOpenSmsPay = openSmsPay;
	}

	public String getPassPort() {

		return passPort;
	}

	public void setPassPort(String passPort) {
		this.passPort = passPort;
	}

	public AppInfoBaseData(String uid,String token,String appKey,String appId,String platformId,String uuid,String channel,String version,String appSecret,int orientation,String passPort,String mobile,boolean isBindMobile,boolean isOpenSmsPay,String appName) {
		this.uid = uid;
		this.token = token;
		this.appKey = appKey;
		this.appId = appId;
		this.platformId = platformId;
		this.uuid = uuid;
		this.channel = channel;
		this.version = version;
		this.appSecret = appSecret;
		this.appName = appName;
		this.passPort = passPort;
		this.mobile = mobile;
		this.isBindMobile = isBindMobile;
		this.isOpenSmsPay = isOpenSmsPay;
		screenOrientation = orientation;
	}

	public String getMobile() {

		return mobile;
	}

	public void setMobile(String moMobile) {
		this.mobile = moMobile;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getPlatformId() {
		return platformId;
	}

	public void setPlatformId(String platformId) {
		this.platformId = platformId;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAppSecret() {
		return appSecret;
	}

	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}

	public int getScreenOrientation() {
		return screenOrientation;
	}

	public void setScreenOrientation(int screenOrientation) {
		this.screenOrientation = screenOrientation;
	}
}
