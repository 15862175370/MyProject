package com.friendtimes.payment.support.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.friendtime.foundation.event.BJMGFSdkEvent;
import com.friendtimes.ft_eventbus.EventBus;

/**
 * Created by liwei002 on 2017/6/23.
 */

public class WXPayBroadcastReciver extends BroadcastReceiver {
    EventBus eventBus = EventBus.getDefault();

    public WXPayBroadcastReciver() {}



    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent.getAction().equals("com.wx.broadcast.cancel")) {
            Log.d("wx", " wx pay cancel");
            eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_CANCEL));
        } else if (intent.getAction().equals("com.wx.broadcast.paysuccess")) {
            eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_SUCCESS));
            Log.d("wx", " wx  pay success");
        } else if (intent.getAction().equals("com.wx.broadcast.payfail")) {
            eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_FAIL));
            Log.d("wx", " wx  pay fail");
        }

    }
}
