package com.friendtimes.payment.utils;

public final class Resource {


    public static final class string {
        public static final String ft_payment_sdk_dock_recharge_sms_pay_prompt_warn_three = "ft_payment_sdk_dock_recharge_sms_pay_prompt_warn_three";
        public static final String ft_payment_sdk_please_login_first = "ft_payment_sdk_please_login_first";
        public static final String ft_payment_sdk_pay_unit = "ft_payment_sdk_pay_unit";
        public static final String ft_payment_sdk_pay_balance = "ft_payment_sdk_pay_balance";
        public static final String ft_payment_sdk_warn_title = "ft_payment_sdk_warn_title";
        public static final String ft_payment_sdk_floatWindow_accountManager_dialog_sure = "ft_payment_sdk_floatWindow_accountManager_dialog_sure";
        public static final String ft_payment_sdk_dock_recharge_ali_pay_order_comfirming = "ft_payment_sdk_dock_recharge_ali_pay_order_comfirming";
        public static final String ft_payment_sdk_dock_recharge_ali_pay_order_cancel = "ft_payment_sdk_dock_recharge_ali_pay_order_cancel";
        public static final String ft_payment_sdk_dock_recharge_ali_pay_order_fail = "ft_payment_sdk_dock_recharge_ali_pay_order_fail";
        public static final String ft_payment_sdk_dock_dialog_to_download_gonow_title = "ft_payment_sdk_dock_dialog_to_download_gonow_title";
        public static final String ft_payment_sdk_dock_dialog_to_download_weixin_app_str = "ft_payment_sdk_dock_dialog_to_download_weixin_app_str";
        public static final String ft_payment_sdk_dock_dialog_to_download_weixin_title = "ft_payment_sdk_dock_dialog_to_download_weixin_title";
        public static final String ft_payment_sdk_dock_dialog_btn_cancel_str = "ft_payment_sdk_dock_dialog_btn_cancel_str";
        public static final String ft_payment_sdk_dock_dialog_btn_continue_str = "ft_payment_sdk_dock_dialog_btn_continue_str";
        public static final String ft_payment_sdk_dock_dialog_btn_ok_str = "ft_payment_sdk_dock_dialog_btn_ok_str";
        public static final String ft_payment_sdk_dock_dialog_btn_return_str = "ft_payment_sdk_dock_dialog_btn_return_str";
        public static final String ft_payment_sdk_dock_pay_center_balance_pay = "ft_payment_sdk_dock_pay_center_balance_pay";
        public static final String ft_payment_sdk_dock_pay_center_balance_pay_need = "ft_payment_sdk_dock_pay_center_balance_pay_need";
        public static final String ft_payment_sdk_dock_pay_center_dialog_title_str = "ft_payment_sdk_dock_pay_center_dialog_title_str";
        public static final String ft_payment_sdk_dock_pay_center_smsPayStr = "ft_payment_sdk_dock_pay_center_smsPayStr";
        public static final String ft_payment_sdk_dock_pay_center_unitStr = "ft_payment_sdk_dock_pay_center_unitStr";
        public static final String ft_payment_sdk_dock_recharge_ali_pay_order_success = "ft_payment_sdk_dock_recharge_ali_pay_order_success";
        public static final String ft_payment_sdk_dock_recharge_cardPay_choose_cardtype_str = "ft_payment_sdk_dock_recharge_cardPay_choose_cardtype_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_choose_operators_str = "ft_payment_sdk_dock_recharge_cardPay_choose_operators_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_chose_str = "ft_payment_sdk_dock_recharge_cardPay_next_chose_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_cardNoValue_str = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_cardNoValue_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_cardPWValue_str = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_cardPWValue_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_dialog_prompt_str = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_dialog_prompt_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_input_prompt_cardno_str = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_input_prompt_cardno_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_input_prompt_cardpw_str = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_input_prompt_cardpw_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_input_prompt_str = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_input_prompt_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_str = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_yuan_space_unit_str = "ft_payment_sdk_dock_recharge_cardPay_yuan_space_unit_str";
        public static final String ft_payment_sdk_dock_recharge_cardPay_yuan_unit_str = "ft_payment_sdk_dock_recharge_cardPay_yuan_unit_str";
        public static final String ft_payment_sdk_dock_recharge_goods_countStr = "ft_payment_sdk_dock_recharge_goods_countStr";
        public static final String ft_payment_sdk_dock_recharge_pleaseChooseMoney = "ft_payment_sdk_dock_recharge_pleaseChooseMoney";
        public static final String ft_payment_sdk_dock_recharge_prompt_paylessStr = "ft_payment_sdk_dock_recharge_prompt_paylessStr";
        public static final String ft_payment_sdk_dock_recharge_prompt_paymoreStr = "ft_payment_sdk_dock_recharge_prompt_paymoreStr";
        public static final String ft_payment_sdk_dock_recharge_rechargeAndbuy = "ft_payment_sdk_dock_recharge_rechargeAndbuy";
        public static final String ft_payment_sdk_http_laoding = "ft_payment_sdk_http_laoding";
        public static final String ft_payment_sdk_no_sim_card = "ft_payment_sdk_no_sim_card";
        public static final String ft_payment_sdk_basepayment_url_not_null = "ft_payment_sdk_basepayment_url_not_null";
        public static final String ft_payment_sdk_rechargecard_url_not_null = "ft_payment_sdk_rechargecard_url_not_null";
        public static final String ft_payment_sdk_chooseoperator = "ft_payment_sdk_chooseoperator";
    }

    public static final class layout {
        public static final String ft_payment_sdk_dock_pay_center_page = "ft_payment_sdk_dock_pay_center_page";
        public static final String ft_payment_sdk_dock_recharge_cardpay_card_item = "ft_payment_sdk_dock_recharge_cardpay_card_item";
        public static final String ft_payment_sdk_dock_recharge_cardpay_next_page = "ft_payment_sdk_dock_recharge_cardpay_next_page";
        public static final String ft_payment_sdk_dock_recharge_cardpay_page = "ft_payment_sdk_dock_recharge_cardpay_page";
        public static final String ft_payment_sdk_dock_recharge_sms_page = "ft_payment_sdk_dock_recharge_sms_page";
        public static final String ft_payment_sdk_real_dialog = "ft_payment_sdk_real_dialog";
        public static final String ft_payment_sdk_recharge_webview = "ft_payment_sdk_recharge_webview";
    }

    public static final class id {
        public static final String ft_payment_sdk_dock_recharge_sms_promptStrId_three = "ft_payment_sdk_dock_recharge_sms_promptStrId_three";
        public static final String bjmgf_sdk_pay_appinfo = "bjmgf_sdk_pay_appinfo";
        public static final String bjmgf_sdk_pay_userinfo = "bjmgf_sdk_pay_userinfo";
        public static final String bjmgf_sdk_pay_price = "bjmgf_sdk_pay_price";
        public static final String bjmgf_sdk_money_for_pay = "bjmgf_sdk_money_for_pay";
        public static final String bjmgf_sdk_smspaygaplineLayoutId = "bjmgf_sdk_smspaygaplineLayoutId";
        public static final String bjmgf_sdk_dock_pay_center_buybtnId = "bjmgf_sdk_dock_pay_center_buybtnId";
        public static final String bjmgf_sdk_dock_pay_center_choosePayType_layoutId = "bjmgf_sdk_dock_pay_center_choosePayType_layoutId";
        public static final String bjmgf_sdk_dock_pay_center_closeLlId = "bjmgf_sdk_dock_pay_center_closeLlId";
        public static final String bjmgf_sdk_dock_pay_center_id = "bjmgf_sdk_dock_pay_center_id";
        public static final String bjmgf_sdk_dock_pay_center_pay_type_alipayId = "bjmgf_sdk_dock_pay_center_pay_type_alipayId";
        public static final String bjmgf_sdk_dock_pay_center_pay_type_rechargeCardPayId = "bjmgf_sdk_dock_pay_center_pay_type_rechargeCardPayId";
        public static final String bjmgf_sdk_dock_pay_center_pay_type_smsPayId = "bjmgf_sdk_dock_pay_center_pay_type_smsPayId";
        public static final String bjmgf_sdk_dock_pay_center_pay_type_unionpayId = "bjmgf_sdk_dock_pay_center_pay_type_unionpayId";
        public static final String bjmgf_sdk_dock_pay_center_recharge_btnllId = "bjmgf_sdk_dock_pay_center_recharge_btnllId";
        public static final String bjmgf_sdk_dock_pay_center_recharge_myBalanceId = "bjmgf_sdk_dock_pay_center_recharge_myBalanceId";
        public static final String bjmgf_sdk_dock_pay_center_recharge_pay_type_rechargeWxPayId = "bjmgf_sdk_dock_pay_center_recharge_pay_type_rechargeWxPayId";
        public static final String bjmgf_sdk_pay_center_priceId = "bjmgf_sdk_pay_center_priceId";
        public static final String bjmgf_sdk_pay_center_prop_count = "bjmgf_sdk_pay_center_prop_count";
        public static final String ft_payment_sdk_dock_recharge_sms_recharge_promptId = "ft_payment_sdk_dock_recharge_sms_recharge_promptId";
        public static final String ft_payment_sdk_dock_recharge_sms_recharge_goodsStrId = "ft_payment_sdk_dock_recharge_sms_recharge_goodsStrId";
        public static final String ft_payment_sdk_back = "ft_payment_sdk_back";
        public static final String ft_payment_sdk_closeAboutBtnId = "ft_payment_sdk_closeAboutBtnId";
        public static final String ft_payment_sdk_closeLlId = "ft_payment_sdk_closeLlId";
        public static final String ft_payment_sdk_dialog_content = "ft_payment_sdk_dialog_content";
        public static final String ft_payment_sdk_dialog_negative_btn = "ft_payment_sdk_dialog_negative_btn";
        public static final String ft_payment_sdk_dialog_positive_btn = "ft_payment_sdk_dialog_positive_btn";
        public static final String ft_payment_sdk_dialog_title = "ft_payment_sdk_dialog_title";
        public static final String ft_payment_sdk_dock_recharge_cardPay_card_BtnId = "ft_payment_sdk_dock_recharge_cardPay_card_BtnId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_chooseMoney_gridviewId = "ft_payment_sdk_dock_recharge_cardPay_chooseMoney_gridviewId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_closeLlId = "ft_payment_sdk_dock_recharge_cardPay_closeLlId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_corp_BtnId = "ft_payment_sdk_dock_recharge_cardPay_corp_BtnId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_nextStepbtnId = "ft_payment_sdk_dock_recharge_cardPay_nextStepbtnId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_cardNoValueId = "ft_payment_sdk_dock_recharge_cardPay_next_cardNoValueId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_cardPWValueId = "ft_payment_sdk_dock_recharge_cardPay_next_cardPWValueId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_chooseResultStrId = "ft_payment_sdk_dock_recharge_cardPay_next_chooseResultStrId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_closeLlId = "ft_payment_sdk_dock_recharge_cardPay_next_closeLlId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_layoutId = "ft_payment_sdk_dock_recharge_cardPay_next_layoutId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_nextStepbtnId = "ft_payment_sdk_dock_recharge_cardPay_next_nextStepbtnId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_goodsStrId = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_goodsStrId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_goods_unitStrId = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_goods_unitStrId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_recharge_promptId = "ft_payment_sdk_dock_recharge_cardPay_next_recharge_promptId";
        public static final String ft_payment_sdk_dock_recharge_cardPay_next_scrollview = "ft_payment_sdk_dock_recharge_cardPay_next_scrollview";
        public static final String ft_payment_sdk_dock_recharge_cardPay_price_Id = "ft_payment_sdk_dock_recharge_cardPay_price_Id";
        public static final String ft_payment_sdk_dock_recharge_cardPay_recharge_goodsStrId = "ft_payment_sdk_dock_recharge_cardPay_recharge_goodsStrId";
        public static final String ft_payment_sdk_dock_recharge_sms_buybtnId = "ft_payment_sdk_dock_recharge_sms_buybtnId";
        public static final String ft_payment_sdk_dock_recharge_sms_closeLlId = "ft_payment_sdk_dock_recharge_sms_closeLlId";
        public static final String ft_payment_sdk_dock_recharge_sms_notice_layoutId = "ft_payment_sdk_dock_recharge_sms_notice_layoutId";
        public static final String ft_payment_sdk_dock_recharge_sms_price_10_Id = "ft_payment_sdk_dock_recharge_sms_price_10_Id";
        public static final String ft_payment_sdk_dock_recharge_sms_price_15_Id = "ft_payment_sdk_dock_recharge_sms_price_15_Id";
        public static final String ft_payment_sdk_dock_recharge_sms_price_20_Id = "ft_payment_sdk_dock_recharge_sms_price_20_Id";
        public static final String ft_payment_sdk_dock_recharge_sms_price_30_Id = "ft_payment_sdk_dock_recharge_sms_price_30_Id";
        public static final String ft_payment_sdk_dock_recharge_sms_price_5_Id = "ft_payment_sdk_dock_recharge_sms_price_5_Id";
        public static final String ft_payment_sdk_messageTextViewId = "ft_payment_sdk_messageTextViewId";
        public static final String ft_payment_sdk_rechargeWebViewId = "ft_payment_sdk_rechargeWebViewId";

    }


    public static final class mipmap {
        public static final String ft_payment_sdk_recharge_item_selected_bg = "ft_payment_sdk_recharge_item_selected_bg";

    }

    public static final class drawable {
        public static final String ft_payment_sdk_back = "ft_payment_sdk_back";
        public static final String ft_payment_sdk_blue_button_big_selector_roundcorner = "ft_payment_sdk_blue_button_big_selector_roundcorner";
        public static final String ft_payment_sdk_button_gray_close = "ft_payment_sdk_button_gray_close";
        public static final String ft_payment_sdk_text_with_roundcorner_selector = "ft_payment_sdk_text_with_roundcorner_selector";
    }

    public static final class dimen {
        public static final String ft_payment_sdk_dock_pay_margin5 = "ft_payment_sdk_dock_pay_margin5";
        public static final String ft_payment_sdk_font_size12 = "ft_payment_sdk_font_size12";
        public static final String ft_payment_sdk_font_size14 = "ft_payment_sdk_font_size14";
        public static final String ft_payment_sdk_font_size16 = "ft_payment_sdk_font_size16";
        public static final String ft_payment_sdk_font_size20 = "ft_payment_sdk_font_size20";
        public static final String ft_payment_sdk_margin0 = "ft_payment_sdk_margin0";
        public static final String ft_payment_sdk_margin10 = "ft_payment_sdk_margin10";
        public static final String ft_payment_sdk_margin15 = "ft_payment_sdk_margin15";
        public static final String ft_payment_sdk_margin20 = "ft_payment_sdk_margin20";
        public static final String ft_payment_sdk_margin5 = "ft_payment_sdk_margin5";
        public static final String ft_payment_sdk_padding10 = "ft_payment_sdk_padding10";
        public static final String ft_payment_sdk_spb_float_ratio = "ft_payment_sdk_spb_float_ratio";
    }

    public static final class color {
        public static final String ft_payment_sdk_black = "ft_payment_sdk_black";
        public static final String ft_payment_sdk_navigation_background = "ft_payment_sdk_navigation_background";
        public static final String ft_payment_sdk_page_background = "ft_payment_sdk_page_background";
        public static final String ft_payment_sdk_text_gray = "ft_payment_sdk_text_gray";
        public static final String ft_payment_sdk_text_price_color = "ft_payment_sdk_text_price_color";
        public static final String ft_payment_sdk_text_wish_role_color = "ft_payment_sdk_text_wish_role_color";
        public static final String ft_payment_sdk_textgray = "ft_payment_sdk_textgray";
        public static final String ft_payment_sdk_white = "ft_payment_sdk_white";
    }

    public static final class styleable {
        public static final String ft_payment_sdk_clearEdit = "ft_payment_sdk_clearEdit";
        public static final String ft_payment_sdk_clearEdit_clear_src = "ft_payment_sdk_clearEdit_clear_src";
        public static final String ft_payment_sdk_clearEdit_warn_title = "ft_payment_sdk_clearEdit_warn_title";
    }

}