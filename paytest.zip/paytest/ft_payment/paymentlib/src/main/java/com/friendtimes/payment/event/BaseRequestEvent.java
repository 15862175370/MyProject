package com.friendtimes.payment.event;

/**
 * Created by wutao on 2015/11/26.
 * 应用基本请求回话类型 ，用来处理在Presenter中 处理 不同的返回 结果
 */
public class BaseRequestEvent {
    public static final int REQUEST_USER_BALANCE               = 39;
    public static final int REQUEST_PAY_ORDER              	   = 40;
    public static final int REQUEST_RECHARGE_ORDER             = 41;
    public static final int REQUEST_PAYMENT_RECHARGE_CARDS_CONFIG_JSON = 50;




}
