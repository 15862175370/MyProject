package com.friendtimes.payment.widget.dialog;


import android.app.Dialog;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.friendtime.foundation.utils.ReflectResourcer;
import com.friendtimes.payment.utils.Resource;

/**
 * 一般对话框 ，主要用于正常业务提醒弹出框
 */

public class BJMSdkDialog extends Dialog {

    private static final String TAG = BJMSdkDialog.class.getCanonicalName();


    private TextView mTitleTextView;
    private TextView mMessageTextView;
    private Button mPositiveButton, mNegativeButton;

    private Window mDialogWindow = null;
    private WindowManager.LayoutParams mLayoutParams = null;

    public boolean mIsPositiveButton = false;
    public boolean mIsNegativeButton = false;

    public BJMSdkDialog(Context context) {
        super(context);

        this.setCancelable(false);

        InitUI(context);
    }

    private void InitUI(Context context) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(ReflectResourcer.getLayoutId(getContext(), Resource.layout.ft_payment_sdk_real_dialog));
        mTitleTextView = (TextView) findViewById(ReflectResourcer.getViewId(getContext(),
                Resource.id.ft_payment_sdk_dialog_title));
        mMessageTextView = (TextView) findViewById(ReflectResourcer.getViewId(getContext(),
                Resource.id.ft_payment_sdk_dialog_content));
        mPositiveButton = (Button) findViewById(ReflectResourcer.getViewId(getContext(),
                Resource.id.ft_payment_sdk_dialog_positive_btn));
        mNegativeButton = (Button) findViewById(ReflectResourcer.getViewId(getContext(),
                Resource.id.ft_payment_sdk_dialog_negative_btn));

        mPositiveButton.getPaint().setFakeBoldText(true);
        mNegativeButton.getPaint().setFakeBoldText(true);


        Log.i("BJMSdkDialog", "init UI");
    }

    @Override
    public void show() {
        fitScreen();
        super.show();
    }

    public void setTitle(String text) {
        mTitleTextView.setText(text);
    }

    public void setMessage(String text) {
        mMessageTextView.setText(text);
    }


    public void setPositiveButton(String text, View.OnClickListener onClickListener) {
        mPositiveButton.setText(text);
        mPositiveButton.setVisibility(View.VISIBLE);
        mPositiveButton.setOnClickListener(onClickListener);
        mIsPositiveButton = true;
    }

    public void setNegativeButton(String text, View.OnClickListener onClickListener) {
        mNegativeButton.setText(text);
        mNegativeButton.setVisibility(View.VISIBLE);
        mNegativeButton.setOnClickListener(onClickListener);
        mIsNegativeButton = true;
    }


    private void fitScreen() {
        WindowManager windowManager = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(dm);
        mDialogWindow = this.getWindow();
        mLayoutParams = mDialogWindow.getAttributes();
        boolean landscapeFlag = dm.widthPixels > dm.heightPixels;
        Log.d("BJMSystemDialog", "landscapeFlag " + landscapeFlag);
        mDialogWindow.setAttributes(mLayoutParams);
        mDialogWindow.setGravity(Gravity.CENTER);
    }

}
