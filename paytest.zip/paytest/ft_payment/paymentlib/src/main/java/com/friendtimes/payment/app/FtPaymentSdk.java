package com.friendtimes.payment.app;

import android.app.Activity;
import android.content.Intent;
import android.text.TextUtils;
import com.friendtime.foundation.bean.PassPort;
import com.friendtime.foundation.event.BJMGFSdkEvent;
import com.friendtime.foundation.tools.BaseSdkTools;
import com.friendtime.foundation.ui.activity.BJMGFActivity;
import com.friendtime.foundation.utils.ToastUtil;
import com.friendtime.foundation.utils.Utility;
import com.friendtimes.ft_eventbus.EventBus;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.ft_tipsdialog.ReflectResourceId;
import com.friendtimes.payment.app.tools.FtSDKTools;
import com.friendtimes.payment.app.tools.PayTools;
import com.friendtimes.payment.event.FtPaymentCallback;
import com.friendtimes.payment.model.entity.AppInfoBaseData;
import com.friendtimes.payment.model.entity.PayOrderData;
import com.friendtimes.payment.ui.activity.WebViewActivity;
import com.friendtimes.payment.ui.view.impl.PaymentCenterView;
import com.friendtimes.payment.utils.Resource;

/**
 * Created by liwei002 on 2016/6/30.
 * 支付组件 对外暴露 类
 */
public class FtPaymentSdk {

	private final String TAG = FtPaymentSdk.class.getSimpleName();
	private static FtPaymentSdk instance;
	private PayTools payTools = PayTools.getInstance();
	FtPaymentCallback ftPaymentCallback;
	EventBus eventBus = EventBus.getDefault();
	private Activity mActivity;
	private PayOrderData payOrderData = null;

	private String publicNumberForPay = "";

	/**
	 * 获得BJMGFSdk类的单例对象
	 *
	 * @return
	 */
	public static FtPaymentSdk getDefault() {
		if (instance == null) {
			synchronized (FtPaymentSdk.class) {
				if (instance == null) {
					instance = new FtPaymentSdk();
				}
			}
		}
		return instance;
	}

	public void onEventMainThread(BJMGFSdkEvent event) {
		LogProxy.i(TAG, "PaymentEvent " + event.getEventId());
		if (ftPaymentCallback != null)
			ftPaymentCallback.onPayCallback(event.getEventId());
		switch (event.getEventId()) {
			case BJMGFSdkEvent.RECHARGE_SUCCESS: //充值成功
				LogProxy.i(TAG, "recharge success");
				break;
			case BJMGFSdkEvent.RECHARGE_FAIL: //充值失败
				LogProxy.i(TAG, "recharge fail");
				break;
			case BJMGFSdkEvent.RECHARGE_CANCEL: // 取消充值
				LogProxy.i(TAG, "recharge cancel");
				break;
			default:
				break;
		}
	}

	/**
	 * 设置是否启用支付回调接口
	 *
	 * @param isOpenPayCallbackMode
	 */
	public void setIsOpenPayCallbackMode(boolean isOpenPayCallbackMode) {
		FtSDKTools.getInstance().setOpenPayCallback(isOpenPayCallbackMode);
	}


	/**
	 * 设置是否开启调试日志模式
	 *
	 * @param isDebug
	 */
	public void setDebugMode(boolean isDebug) {
		LogProxy.setDebugMode(isDebug);
	}

	/**
	 * 传入充值数据类
	 *
	 * @param payOrderData 充值数据类
	 */
	private void paymentDataJson(PayOrderData payOrderData) {

		payTools.setPayOrderData(payOrderData);
	}

	/**
	 * 传入基础信息类
	 *
	 * @param appInfoBaseData 基础信息类
	 */
	private void appInfoDataJson(AppInfoBaseData appInfoBaseData) {
		payTools.setAppInfoBaseData(appInfoBaseData);
	}

	/**
	 * 社交平台调用
	 * 充值 ，带有支付回调
	 *
	 * @param activity             上下文
	 * @param isWrapRecharge       是否为网页充值
	 * @param basePaymentDomainUrl 基本业务根域名地址
	 * @param rechargeCardUrl      充值卡配置参数地址
	 * @param callback             支付回调
	 */
	public void rechargeProduct(Activity activity, boolean isWrapRecharge, String basePaymentDomainUrl, String rechargeCardUrl, FtPaymentCallback callback, String webRechargeUrl, AppInfoBaseData appInfoBaseData, PayOrderData payOrderData, PassPort passport) {
		mActivity =activity;
		PayTools.getInstance().setCurrentPassPort(passport);
		payTools.setIsInsideUse(false);
		if (TextUtils.isEmpty(basePaymentDomainUrl)) {
			ToastUtil.showMessage(activity, Utility.getString(Resource.string.ft_payment_sdk_basepayment_url_not_null, activity));
			return;
		}

		if (TextUtils.isEmpty(rechargeCardUrl)) {
			ToastUtil.showMessage(activity, Utility.getString(Resource.string.ft_payment_sdk_rechargecard_url_not_null, activity));
			return;
		}
		PayTools.getInstance().setBasePaymentDomainUrl(basePaymentDomainUrl);
		PayTools.getInstance().setRechargeCardUrl(rechargeCardUrl);
		PayTools.getInstance().setWebRechargeUrl(webRechargeUrl);
		appInfoDataJson(appInfoBaseData);
		paymentDataJson(payOrderData);
		this.ftPaymentCallback = callback;
		if (!eventBus.isRegistered(this))
			eventBus.register(this);
		if (passport == null) {
			ToastUtil.showMessage(activity, activity.getResources().getString(ReflectResourceId.getStringId(activity, Resource.string.ft_payment_sdk_please_login_first)), true);
		} else {
			//是否为网页充值判断
			if (isWrapRecharge) {
				rechargeProductOriginal(activity);
			} else {
				rechargeProductSDK(activity);
			}
		}
	}

	/**
	 * SDK调用接口
	 *
	 * @param activity    上下文
	 * @param orderSerial 订单号
	 * @param productId   产品ID
	 * @param productName 产品名称
	 * @param count       产品数量
	 * @param money       充值金额
	 * @param serverId    服务器ID
	 * @param roleId      角色ID
	 */
	public void rechargeProduct(final Activity activity, final String orderSerial, final String productId, final String productName, final int count, final float money, final String serverId, final String roleId) {
		mActivity = activity;
		if (BaseSdkTools.getInstance().getCurrentPassPort() == null) {
			ToastUtil.showMessage(activity, activity.getResources().getString(ReflectResourceId.getStringId(activity, Resource.string.ft_payment_sdk_please_login_first)), true);
		} else {
			payOrderData = new PayOrderData(orderSerial, productId, productName, count, money, serverId, roleId, "", "", "", "", "", "");
			payTools.setPayOrderData(payOrderData);
			payTools.setIsInsideUse(true);
			if (payTools.getIsWapRecharge()) {
				rechargeProductOriginal(activity);
			} else {
				rechargeProductSDK(activity);
			}
		}
	}

	/**
	 * 用户充值 web端充值
	 *
	 * @param activity
	 */
	public void rechargeProductOriginal(Activity activity) {

		BJMGFActivity.canLandscape = true;
		Intent intent = new Intent(activity, WebViewActivity.class);
		activity.startActivity(intent);
	}

	/**
	 * 用户充值 非web端充值
	 *
	 * @param activity
	 */
	public void rechargeProductSDK(Activity activity) {
		BJMGFActivity.canLandscape = true;
		Intent intent = new Intent(activity, BJMGFActivity.class);
		intent.putExtra(BJMGFActivity.Page_Class_Name_Key,
				PaymentCenterView.class.getCanonicalName());
		activity.startActivity(intent);

	}
	/**
	 * 获得Activity
	 *
	 * @return
	 */
	public Activity getActivity() {

		return mActivity;

	}

	/**
	 * 是否打开短信支付（游戏传入） 如果不想开启 请传入false即可
	 *
	 * @param isOpenSmsPay 短信支付开关
	 */
	public void setIsOpenSmsPay(boolean isOpenSmsPay) {
		FtSDKTools.getInstance().isOpenSmsPay = isOpenSmsPay;
	}

	/**
	 * 是否打开短信支付（sdk传入） 如果不想开启 请传入false即可
	 *
	 * @param isSDKOpenSmsPay 短信支付开关
	 */
	public void setIsSDKOpenSmsPay(boolean isSDKOpenSmsPay) {
		FtSDKTools.getInstance().isSDKOpenSmsPay = isSDKOpenSmsPay;
	}

	/**
	 * 设置是否为网页充值 SDK端调用使用
	 */
	public void setIsWapRecharge(boolean isWapRecharge) {
		payTools.setIsWapRecharge(isWapRecharge);
	}

	/**
	 * 获取客服公众号
	 * @return
	 */
	public String getPublicNumberForPay() {
		return publicNumberForPay;
	}

	/**
	 * 设置客服公众号
	 * @return
	 */
	public void setPublicNumberForPay(String publicNumberForPay) {
		this.publicNumberForPay = publicNumberForPay;
	}
}
