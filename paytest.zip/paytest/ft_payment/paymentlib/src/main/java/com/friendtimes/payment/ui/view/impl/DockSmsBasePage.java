package com.friendtimes.payment.ui.view.impl;

import android.content.Context;
import android.view.View;

import com.friendtime.foundation.utils.ReflectResourcer;
import com.friendtimes.ft_logger.LogProxy;


public abstract class DockSmsBasePage {

	protected View view = null;
	protected Context context = null;

	public DockSmsBasePage(Context context, String layoutId) {
		this.context = context;
		view = View.inflate(context,
				ReflectResourcer.getLayoutId(context, layoutId), null);
		setView();
	}
	
	public abstract void setView();

	/**
	 * 泛型简化findviewById方法
	 * 
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected final <E extends View> E getView(String id) {
		try {
			return (E) view.findViewById(ReflectResourcer.getViewId(context,
					id));
		} catch (ClassCastException ex) {
			LogProxy.e("BJMEngine", "Could not cast View to concrete class."
					+ ex);
			throw ex;
		}
	}

	public View getView() {
		return view;
	}
}
