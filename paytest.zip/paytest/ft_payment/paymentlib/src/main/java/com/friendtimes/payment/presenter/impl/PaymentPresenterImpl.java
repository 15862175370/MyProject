package com.friendtimes.payment.presenter.impl;

import android.content.Context;

import com.bojoy.collect.BojoyCollect;
import com.bojoy.collect.config.CollectEventConstants;
import com.bojoy.collect.info.impl.NetWorkErrorInfo;
import com.friendtime.foundation.bean.AppInfoData;
import com.friendtime.foundation.config.SysConstants;
import com.friendtime.foundation.tools.BaseSdkTools;
import com.friendtimes.payment.ui.IBaseView;
import com.friendtime.foundation.utils.StringUtility;
import com.friendtimes.ft_fastjson.JSON;
import com.friendtimes.ft_fastjson.JSONArray;
import com.friendtimes.ft_fastjson.JSONObject;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.http.bean.BackResultBean;
import com.friendtimes.http.callback.BaseResultCallbackListener;
import com.friendtimes.payment.app.FtPaymentSdk;
import com.friendtimes.payment.config.ErrorCode;
import com.friendtimes.payment.config.PaySysConstant;
import com.friendtimes.payment.event.BaseRequestEvent;
import com.friendtimes.payment.model.IPaymentModel;
import com.friendtimes.payment.model.entity.PayOrderData;
import com.friendtimes.payment.model.entity.RechargeCardDetailData;
import com.friendtimes.payment.model.impl.PaymentModelImpl;
import com.friendtimes.payment.presenter.IPaymentPresenter;
import com.friendtimes.payment.ui.view.IPayRechargeCardView;
import com.friendtimes.payment.ui.view.IPayRechargeCardViewNext;
import com.friendtimes.payment.ui.view.IPaymentView;
import com.mistyrain.okhttp.Call;

import java.util.ArrayList;
import java.util.Map;

import static com.friendtimes.payment.config.ErrorCode.ERROR_CODE_RECHARGECARDRESULTCODE_ORDERNUMBER_REPEAT_ERROR;

/**
 * Created by wutao on 2016/1/22. 支付业务 控制器实现
 */
public class PaymentPresenterImpl implements IPaymentPresenter, BaseResultCallbackListener {

	private final String TAG = PaymentPresenterImpl.class.getSimpleName();
	private Context mContext;
	private IPaymentModel iPaymentModel;
	private String payType; // 支付类型
	private IBaseView iBaseView;
	public PaymentPresenterImpl(Context context, IBaseView iBaseView) {
		this.mContext = context;
		this.iBaseView = iBaseView;
		this.iPaymentModel = new PaymentModelImpl();
	}

	/**
	 * 解析常见的json字符串 充值卡数据类的json解析
	 */
	@Override
	public void onSuccess(Object response, int requestSessionEvent, String requetApiName) {

		try {
			if (requestSessionEvent == BaseRequestEvent.REQUEST_PAYMENT_RECHARGE_CARDS_CONFIG_JSON) {

				if (!StringUtility.isEmpty(String.valueOf(response))) {
					Object obj = JSONObject.parseObject(
							String.valueOf(response)).get("rechargecard");
					JSONArray array = JSONArray.parseArray(obj.toString());

					ArrayList<RechargeCardDetailData> list = new ArrayList<RechargeCardDetailData>();
					for (int i = 0; i < array.size(); i++) {
						list.add(JSONObject.parseObject(array.getJSONObject(i)
										.get(String.valueOf(111 + i)).toString(),
								RechargeCardDetailData.class));

					}

					for (int i = 0; i < list.size(); i++) {
						list.get(i).id = String.valueOf(111 + i);

					}
					((IPayRechargeCardView) iBaseView).showRechargeResult(list);
				} else LogProxy.d(TAG, "response is null");

			} else {
				BackResultBean backResultBean = JSON.parseObject(
						(String) response, BackResultBean.class);
				//因为充值卡成功返回的结果码不为0故重写以和其他充值结果区分
				if (backResultBean.getCode() == ErrorCode.ERROR_CODE_RECHARGECARDRESULTCODE_SUCCESS) {
					if (requestSessionEvent == BaseRequestEvent.REQUEST_RECHARGE_ORDER) {
						String msg = backResultBean.getMsg().toString();
						((IPayRechargeCardViewNext) iBaseView).showReturn(msg);
					}
				}
				if (backResultBean.getCode() == ErrorCode.ERROR_CODE_RECHARGECARDRESULTCODE_ERROR || backResultBean.getCode() == ERROR_CODE_RECHARGECARDRESULTCODE_ORDERNUMBER_REPEAT_ERROR) {
					String msg = backResultBean.getMsg().toString();
					if (payType.equals(PaySysConstant.ALIPAY_TYPE) || payType.equals(PaySysConstant.SMSPAY_TYPE) || payType.equals(PaySysConstant.WXPAY_TYPE)||payType
							.equals(PaySysConstant.UNIONPAY_TYPE)) {
						((IPaymentView) iBaseView).showError(msg,backResultBean.getCode());
					}else {
						((IPayRechargeCardViewNext) iBaseView).showError(msg,backResultBean.getCode());
					}

				}
				//如果u币余额不足时支付调用此方法 因为U币余额不足支付与余额充足支付返回码不同故重写
				if (backResultBean.getCode() == ErrorCode.ERROR_CODE_PAYORDERCODE) {
					if (requestSessionEvent == BaseRequestEvent.REQUEST_PAY_ORDER) {
						String backMsg = backResultBean.getMsg().toString();
						((IPaymentView) iBaseView).getPayResult("", backMsg);
					}
				}

				if (backResultBean.getCode() == ErrorCode.ERROR_CODE_SUCCESS) {
					switch (requestSessionEvent) {
						case BaseRequestEvent.REQUEST_USER_BALANCE:// 获取U币余额
							String balance = JSON
									.parseObject(backResultBean.getObj(), Map.class)
									.get("data").toString();
							if (!StringUtility.isEmpty(balance)) {
								((IPaymentView) iBaseView).showResult(balance);
							} else {
								LogProxy.d(TAG, "balance is null");
							}
							break;
						case BaseRequestEvent.REQUEST_RECHARGE_ORDER:

							if (payType.equals(PaySysConstant.ALIPAY_TYPE) || payType.equals(PaySysConstant.SMSPAY_TYPE) || payType.equals(PaySysConstant.WXPAY_TYPE)) {

								String payInfo = JSON
										.parseObject(backResultBean.getObj(),
												Map.class).get("payInfo")
										.toString();
								((IPaymentView) iBaseView).getPayInfo(payInfo);
							} else if (payType
									.equals(PaySysConstant.UNIONPAY_TYPE)) {
								String tn = JSON
										.parseObject(backResultBean.getObj(),
												Map.class).get("tn").toString();
								String serverMode = JSON
										.parseObject(backResultBean.getObj(),
												Map.class).get("serverMode")
										.toString();
								((IPaymentView) iBaseView).getUnionInfo(tn, serverMode);
							} else if (payType.equals(PaySysConstant.CM_CARD_PAY_TYPE)) {


							} else if (payType.equals(PaySysConstant.CT_CARD_PAY_TYPE)) {

							} else if (payType.equals(PaySysConstant.CU_CARD_PAY_TYPE)) {

							}
							break;
						case BaseRequestEvent.REQUEST_PAY_ORDER:
							String data = JSON
									.parseObject(backResultBean.getObj(),
											Map.class).get("data").toString();
							String backMsg = backResultBean.getMsg().toString();
							((IPaymentView) iBaseView).getPayResult(data, backMsg);
							break;
					}

				} else {
					((IPaymentView) iBaseView).showError(backResultBean.getMsg(),backResultBean.getCode());

					NetWorkErrorInfo netWorkErrorInfo = new NetWorkErrorInfo();
					netWorkErrorInfo.setAskType(CollectEventConstants.COL_CLIENT_TIPS_EXCEPTION_TYPE);
					netWorkErrorInfo.setAskUrl(requetApiName);
					netWorkErrorInfo.setErrorCode(String.valueOf(backResultBean.getCode()));
					netWorkErrorInfo.setErrorMsg(backResultBean.getMsg());
					netWorkErrorInfo.setSdkVersion(AppInfoData.getSdkVersion());
					netWorkErrorInfo.setUserId(BaseSdkTools.getInstance().getCurrentPassPort() != null ? BaseSdkTools.getInstance().getCurrentPassPort().getUid() : "");

					BojoyCollect.getInstance().collectNetWorkError(FtPaymentSdk.getDefault().getActivity(), netWorkErrorInfo);


				}

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	@Override
	public void onError(Call request, String errorCode, Exception exception,
						int requestSessionEvent, String requestApiName) {
		if (((IPaymentView) iBaseView) != null) {
			((IPaymentView) iBaseView).showError(exception.getMessage() + "", Integer.valueOf(errorCode));
		}
	}

	/**
	 * 請求查询用戶賬戶余额 context 上下文
	 */

	@Override
	public void requestUBalance(Context context) {

		iPaymentModel.getUBalance(context, this);
	}

	/**
	 * 请求创建订单
	 */
	@Override
	public void submitOrder(Context context,
							PayOrderData payOrderData) {
		this.payType = payOrderData.getPayID();
		LogProxy.d("this payType is", payType);
		iPaymentModel.getSubmitOrder(context, payOrderData, this);

	}

	/**
	 * 请求支付
	 */
	@Override
	public void requestPay(Context context,
						   PayOrderData payOrderData) {
		iPaymentModel.getRequestPayModel(context, payOrderData, this);

	}

	/**
	 * 请求获得充值数据信息
	 */
	@Override
	public void getRechargeCardDes(Context context) {
		iPaymentModel.getRechargeCardDetailDataWithURL(context, this);

	}

	/**
	 * 短信支付
	 */
	@Override
	public void startSmsPay(Context context,
							PayOrderData payOrderData) {
		this.payType = payOrderData.getPayID();
		iPaymentModel.getSubmitOrder(context, payOrderData, this);

	}

}
