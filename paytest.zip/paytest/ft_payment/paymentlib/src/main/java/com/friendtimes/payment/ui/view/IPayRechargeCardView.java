package com.friendtimes.payment.ui.view;

import com.friendtimes.payment.ui.IBaseView;
import com.friendtimes.payment.model.entity.RechargeCardDetailData;

import java.util.ArrayList;


public interface IPayRechargeCardView extends IBaseView {
	/**
	 * 充值卡充值json解析后从presenter返回的数据
	 * @param list
	 */
	void showRechargeResult(ArrayList<RechargeCardDetailData> list);
}
