package com.friendtimes.payment.model.impl;

import android.content.Context;

import com.friendtime.foundation.utils.DateUtil;
import com.friendtime.foundation.utils.StringUtility;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.http.HttpUtility;
import com.friendtimes.http.callback.BaseResultCallbackListener;
import com.friendtimes.http.callback.FileCallback;
import com.friendtimes.http.callback.StringCallback;
import com.friendtimes.http.config.HttpMethod;
import com.friendtimes.payment.api.BaseApi;
import com.friendtimes.payment.app.tools.ParamsTools;
import com.friendtimes.payment.app.tools.PayTools;
import com.friendtimes.payment.config.PaySysConstant;
import com.friendtimes.payment.event.BaseRequestEvent;
import com.friendtimes.payment.model.IPaymentModel;
import com.friendtimes.payment.model.entity.PayOrderData;
import com.friendtimes.payment.utils.DomainUtility;
import com.mistyrain.okhttp.Call;
import com.mistyrain.okhttp.Response;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

/**
 * Created by wutao on 2016/1/22.
 */
public class PaymentModelImpl implements IPaymentModel {
    private FileInputStream instream;
    private final String TAG = PaymentModelImpl.class.getSimpleName();

    /**
     * 用户账户U币余额查询方法
     *
     * @param context  上下文
     * @param listener 结果回调接口 将查询结果返回到presenter
     */
    @Override
    public void getUBalance(final Context context,
                            final BaseResultCallbackListener listener) {

        final Map<String, String> params = ParamsTools.getInstance()
                .getFoundationParamsMap(context);
        params.put("formatObjType", "object");
        try {
          String   getUBalanceUrl = "";
            if(PayTools.getInstance().getIsInsideUse()){
                getUBalanceUrl = DomainUtility.getInstance().getServiceSDKDomain(context)
                        + BaseApi.APP_U_BLANCE;
            }else {
                getUBalanceUrl = PayTools.getInstance().getBasePaymentDomainUrl() + BaseApi.APP_U_BLANCE;
            }
            HttpUtility.getInstance().execute(
                      HttpMethod.POST, getUBalanceUrl, params,
                      new StringCallback() {
                          @Override
                          public void onError(Call call, Response response, Exception e) {
                              listener.onError(call, String.valueOf(response.code()), e,
                                        BaseRequestEvent.REQUEST_USER_BALANCE, BaseApi.APP_U_BLANCE);
                          }

                          @Override
                          public void onResponse(String response) {

                              LogProxy.i(TAG, response.toString());

                              listener.onSuccess(response,
                                        BaseRequestEvent.REQUEST_USER_BALANCE, BaseApi.APP_U_BLANCE);
                          }
                      });
        } catch (Exception e) {
            e.printStackTrace();
            LogProxy.d(TAG, e.getMessage());
        }
    }

    /**
     * 请求生成支付订单
     *
     * @param context  上下文
     * @param listener 回调 将结果通知presenter
     */
    @Override
    public void getSubmitOrder(Context context,
                               PayOrderData payOrderData,
                               final BaseResultCallbackListener listener) {

        Map<String, String> params = ParamsTools.getInstance()
                  .getPaymentParamsMap(context, payOrderData);

        try {
            String   getSubmitOrder = "";
            if(PayTools.getInstance().getIsInsideUse()){
                getSubmitOrder = DomainUtility.getInstance().getServiceSDKDomain(context) + BaseApi.APP_SUBMIT_ORDER;
            }else {
                getSubmitOrder = PayTools.getInstance().getBasePaymentDomainUrl() + BaseApi.APP_SUBMIT_ORDER;
            }
            HttpUtility.getInstance().execute(
                      HttpMethod.POST,
                    getSubmitOrder, params,
                      new StringCallback() {

                          @Override
                          public void onError(Call call, Response response, Exception e) {

                              listener.onError(call
                                        , String.valueOf(response.code()), e,
                                        BaseRequestEvent.REQUEST_RECHARGE_ORDER, BaseApi.APP_SUBMIT_ORDER);
                          }

                          @Override
                          public void onResponse(String response) {
                              listener.onSuccess(response,
                                        BaseRequestEvent.REQUEST_RECHARGE_ORDER, BaseApi.APP_SUBMIT_ORDER);

                              LogProxy.d(TAG, response + "");

                          }
                      });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 余额足够支付时 支付U币
     *
     * @param context  上下文
     * @param listener 回调 将结果通知presenter
     */
    @Override
    public void getRequestPayModel(Context context,
                                   PayOrderData payOrderData,
                                   final BaseResultCallbackListener listener) {

        Map<String, String> params = ParamsTools.getInstance()
                  .getPayOrderParams(context, payOrderData);

        try {
            String   getRequestPayModel = "";
            if(PayTools.getInstance().getIsInsideUse()){
                getRequestPayModel =  DomainUtility.getInstance().getServiceSDKDomain(context) + BaseApi.APP_PAY_ORDER;
            }else {
                getRequestPayModel =  PayTools.getInstance().getBasePaymentDomainUrl() + BaseApi.APP_PAY_ORDER;
            }
            HttpUtility.getInstance().execute(
                      HttpMethod.POST,
                    getRequestPayModel, params,
                      new StringCallback() {

                          @Override
                          public void onError(Call call, Response response, Exception e) {
                              listener.onError(call, String.valueOf(response.code()), e,
                                        BaseRequestEvent.REQUEST_PAY_ORDER, BaseApi.APP_PAY_ORDER);

                          }

                          @Override
                          public void onResponse(String response) {
                              listener.onSuccess(response,
                                        BaseRequestEvent.REQUEST_PAY_ORDER, BaseApi.APP_PAY_ORDER);
                          }

                      });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    ;

    /**
     * 充值卡数据信息json解析
     *
     * @param context  上下文
     * @param listener 将结果通知presenter
     */
    @Override
    public void getRechargeCardDetailDataWithURL(final Context context,
                                                 final BaseResultCallbackListener listener) {
        String version = DateUtil.getCurrentTime();
       String  getRechargeCardUrl = "";
        if(PayTools.getInstance().getIsInsideUse()){
            getRechargeCardUrl = DomainUtility.getInstance().getRechargCardUrl(context);
        }else{
            getRechargeCardUrl = PayTools.getInstance().getRechargeCardUrl();
        }
        if (StringUtility.isEmpty(getRechargeCardUrl) && StringUtility.isEmpty(version)) {
            return;
        }
        File file = new File(context.getFilesDir().toString() + File.separator
                  + PaySysConstant.PAYMENT_RECHARGE_CARDS_CONFIG);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }

        try {
            HttpUtility.getInstance().executeDownloadFile(getRechargeCardUrl + version, new FileCallback(context.getFilesDir().toString(), PaySysConstant.PAYMENT_RECHARGE_CARDS_CONFIG) {
                @Override
                public void inProgress(float progress) {

                }

                @Override
                public void onError(Call call, Response response, Exception e) {
                    LogProxy.d(TAG, "onError=" + "request=" + call
                              + "\texception=" + e);
                    // 浠庣綉缁滆幏鍙栨枃浠跺け璐?
                    listener.onError(
                              call, String.valueOf(response.code()),
                              e,
                              BaseRequestEvent.REQUEST_PAYMENT_RECHARGE_CARDS_CONFIG_JSON, PaySysConstant.PAYMENT_RECHARGE_CARDS_CONFIG);
                }

                @Override
                public void onResponse(File response) {
                    // response:文件路径
                    LogProxy.d(TAG, response.getPath());
                    // 调用文件读取
                    getRechargeCardDetailDataWithFile(context, listener);
                }
            });
        } catch (Exception e) {
            LogProxy.d(TAG, e.getMessage());
        }
    }


    /**
     * 从文件系统中获取json文件
     *
     * @param context  上下文
     * @param listener 回调 将结果通知presenter
     */
    @Override
    public void getRechargeCardDetailDataWithFile(Context context,
                                                  final BaseResultCallbackListener listener) {
        File file = new File(context.getFilesDir().toString() + File.separator
                  + PaySysConstant.PAYMENT_RECHARGE_CARDS_CONFIG);
        StringBuilder content = new StringBuilder();

        try {
            instream = new FileInputStream(file.getPath());

            if (instream != null) {

                InputStreamReader inputreader = new InputStreamReader(instream);
                BufferedReader buffreader = new BufferedReader(inputreader);
                String line;
                // 分行读取
                while ((line = buffreader.readLine()) != null) {
                    content.append(line + "\n");
                }
                instream.close();
            }
        } catch (java.io.FileNotFoundException e) {
            LogProxy.d(TAG, "The File doesn't not exist.");
        } catch (IOException e) {
            LogProxy.d(TAG, e.getMessage());
        }
        LogProxy.d(TAG, content.toString());
        if (!StringUtility.isEmpty(content.toString())) {
            listener.onSuccess(content.toString(),
                      BaseRequestEvent.REQUEST_PAYMENT_RECHARGE_CARDS_CONFIG_JSON, "getRechargeCardJson");
        } else {
            //如果没有取到网络数据取本地数据
            String localstr = "{rechargecard: [{111: {text: \"移动充值卡支付\",tip: \"移动充值卡\",ct: [{id: \"CMJFK00010001\",name: \"全国移动充值卡\",cardNumberLength: 17,cardPwdLength: 18,rule: [10, 20, 30, 50, 100, 200, 300, 500]},{id: \"CMJFK00010112\", name: \"浙江移动缴费券\", cardNumberLength: 10, cardPwdLength: 8, rule: [10, 20, 30, 50, 100, 200]}, {id: \"CMJFK00010014\", name: \"福建呱呱通充值卡\", cardNumberLength: 16, cardPwdLength: 17, rule: [10, 20, 30, 50, 100]}]}}, {112: {text: \"联通充值卡支付\", tip: \"联通充值卡\", ct: [{id: \"LTJFK00020000\", name: \"全国联通一卡充\", cardNumberLength: 15, cardPwdLength: 19, rule: [10,20,30,50,100,200,300,500]}]}}, {113: { text: \"电信充值卡支付\", tip: \"电信充值卡\", ct: [{id : \"DXJFK00010001\", name: \"全国电信卡\", cardNumberLength: 19, cardPwdLength: 18, rule: [10, 20, 30, 50, 100, 200]}]}}]}";
            listener.onSuccess(localstr,
                      BaseRequestEvent.REQUEST_PAYMENT_RECHARGE_CARDS_CONFIG_JSON, "getRechargeCardJson");
        }

    }


}
