package com.friendtimes.payment.api;

/**
 * Created by liwei002 on 2016/6/30.
 */
public class BaseApi {
    //支付业务请求前缀
    public static final String BASE_PAY_ROOT = "/gf/pay/sdk/";
    //提交订单
    public static final String APP_SUBMIT_ORDER = BASE_PAY_ROOT + "mobileorder.do";
    //U币查询
    public static final String APP_U_BLANCE = BASE_PAY_ROOT + "balance.do";
    //支付U币
    public static final String APP_PAY_ORDER = BASE_PAY_ROOT + "reduce.do";
    //网页充值
    public static final String APP_WAP_RECHARGE = BASE_PAY_ROOT + "init.do";

}
