package com.friendtimes.payment.ui.view.impl;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.friendtime.foundation.bean.AppGameInfo;
import com.friendtime.foundation.event.BJMGFSdkEvent;
import com.friendtime.foundation.listener.ErrorCodeAction;
import com.friendtime.foundation.tools.BaseSdkTools;
import com.friendtime.foundation.ui.activity.BJMGFActivity;
import com.friendtime.foundation.ui.page.BaseActivityPage;
import com.friendtime.foundation.ui.page.PageManager;
import com.friendtime.foundation.utils.DeviceUtil;
import com.friendtime.foundation.utils.StringUtility;
import com.friendtime.foundation.utils.ToastUtil;
import com.friendtime.foundation.utils.UIUtil;
import com.friendtime.foundation.utils.Utility;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.ft_tipsdialog.ReflectResourceId;
import com.friendtimes.ft_tipsdialog.TipsDialogUtil;
import com.friendtimes.payment.app.tools.FtSDKTools;
import com.friendtimes.payment.app.tools.PayTools;
import com.friendtimes.payment.config.PaySysConstant;
import com.friendtimes.payment.model.entity.PayOrderData;
import com.friendtimes.payment.model.entity.PayResult;
import com.friendtimes.payment.presenter.IPaymentPresenter;
import com.friendtimes.payment.presenter.impl.PaymentPresenterImpl;
import com.friendtimes.payment.ui.view.IPaymentView;
import com.friendtimes.payment.utils.DomainUtility;
import com.friendtimes.payment.utils.Resource;
import com.friendtimes.payment.utils.payment.WeiChatPayUtil;
import com.unionpay.UPPayAssistEx;

import java.text.DecimalFormat;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


/**
 * Created by wutao on 2016/1/22. 支付中心 视图
 */
public class PaymentCenterView extends BaseActivityPage implements IPaymentView {

    private final String TAG = PaymentCenterView.class.getSimpleName();

    private RelativeLayout mBackLayout = null;
    private PayOrderData payOrderData = null;
    private TextView goodsName = null;
    private TextView goodsPrice = null;
    private PayTools payTools = PayTools.getInstance();
    private RelativeLayout rechargeBtnLayout = null;
    private TextView mTitle = null;
    private View smsPayGapLineLayout;//短信支付分割线
    // 充值方式选择
    private LinearLayout payTypeLayout = null;
    //支付宝充值
    private TextView alipayTextView = null;
    //银联充值
    private TextView unionPayTextView = null;
    //短信充值
    private TextView smsPayTextView = null;
    //充值卡充值
    private TextView rechargeCardPayTextView = null;
    //微信充值
    private TextView rechargeWxPayTextView = null;
    //支付按钮
    private Button payBtn = null;
    //账户余额  U币数量
    public int balance = 0;
    //支付方式选择
    private String mType;
    //需要充值的U币数量
    public int deltaMoney = 0;
    private static final int SDK_PAY_FLAG = 1;
    private static final int SDK_CHECK_FLAG = 2;
    IPaymentPresenter iPaymentPresenter = null;
    private String chargeWarnProductName = "";
    private double chargeWarnProducttPrice = 0;


    private int eventWarn = 0;

    private TextView mAppInfoTextView, mProductPrice, mPayUserInfo, mMoneyForPay;

    /**
     * 支付宝支付返回的支付结果
     */
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SDK_PAY_FLAG: {
                    PayResult payResult = new PayResult((Map<String, String>) msg.obj);
                    // 支付宝返回此次支付结果及加签，建议对支付宝签名信息拿签约时支付宝提供的公钥做验签
                    String resultInfo = payResult.getResult();
                    String resultStatus = payResult.getResultStatus();
                    LogProxy.i(TAG, " resultStatus =" + resultStatus);
                    // 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
                    if (TextUtils.equals(resultStatus, "9000")) {
                        Toast.makeText(activity, getString(Resource.string.ft_payment_sdk_dock_recharge_ali_pay_order_success), Toast.LENGTH_SHORT).show();
                        payTools.clearPayDatas();// 清除订单信息
                        eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_SUCCESS));

                        quit();
                    } else if (TextUtils.equals(resultStatus, "6001")) {
                        Toast.makeText(activity, getString(Resource.string.ft_payment_sdk_dock_recharge_ali_pay_order_cancel), Toast.LENGTH_SHORT).show();
                        eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_CANCEL));
                        quit();
                    } else {
                        // 判断resultStatus 为非“9000”则代表可能支付失败
                        // “8000”代表支付结果因为支付渠道原因或者系统原因还在等待支付结果确认，最终交易是否成功以服务端异步通知为准（小概率状态）
                        if (TextUtils.equals(resultStatus, "8000")) {
                            Toast.makeText(activity, getString(Resource.string.ft_payment_sdk_dock_recharge_ali_pay_order_comfirming), Toast.LENGTH_SHORT).show();
                        } else {
                            // 其他值就可以判断为支付失败，包括用户主动取消支付，或者系统返回的错误
                            Toast.makeText(activity, getString(Resource.string.ft_payment_sdk_dock_recharge_ali_pay_order_fail), Toast.LENGTH_SHORT).show();

                        }
                        eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_FAIL));
                        quit();
                    }
                    break;
                }
                case SDK_CHECK_FLAG: {
                    break;
                }
                default:
                    break;
            }

        }

    };

    public PaymentCenterView(Context context, PageManager manager, BJMGFActivity activity) {
        super(ReflectResourceId.getLayoutId(context, Resource.layout.ft_payment_sdk_dock_pay_center_page), context, manager, activity);
        payOrderData = payTools.getPayOrderData();
        deltaMoney = 0;
        iPaymentPresenter = new PaymentPresenterImpl(context, this);

    }

    @Override
    public void onCreateView(View view) {
        mMoneyForPay = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_money_for_pay));
        mPayUserInfo = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_pay_userinfo));
        mProductPrice = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_pay_price));
        mAppInfoTextView = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_pay_appinfo));
        mBackLayout = getView(Resource.id.bjmgf_sdk_dock_pay_center_closeLlId);
        goodsName = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_pay_center_prop_count));
        goodsPrice = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_pay_center_priceId));
        mTitle = getView(Resource.id.bjmgf_sdk_dock_pay_center_id);
        smsPayGapLineLayout = getView(Resource.id.bjmgf_sdk_smspaygaplineLayoutId);
        payTypeLayout = (LinearLayout) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_choosePayType_layoutId));
        payBtn = (Button) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_buybtnId));

        alipayTextView = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_pay_type_alipayId));

        unionPayTextView = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_pay_type_unionpayId));

        smsPayTextView = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_pay_type_smsPayId));

        rechargeCardPayTextView = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_pay_type_rechargeCardPayId));

        rechargeWxPayTextView = (TextView) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_recharge_pay_type_rechargeWxPayId));
        rechargeBtnLayout = (RelativeLayout) view.findViewById(ReflectResourceId.getViewId(context, Resource.id.bjmgf_sdk_dock_pay_center_recharge_btnllId));// 充值按钮
        dealWithEvent();

        super.onCreateView(view);
    }

    private void dealWithEvent() {
        rechargeBtnLayout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {// 充值按钮

            }
        });
        mBackLayout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                payTools.clearPayDatas();// 清除订单信息
                eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_CANCEL));
                quit(); // REVIEW 是否取消订单 弹出对话框
            }
        });

        /**
         * 支付宝支付
         */

        alipayTextView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                mType = PaySysConstant.ALIPAY_TYPE;
                payTools.setCurrentType(mType);
                PayOrderData mPayOrderData = payTools.getRequestParms(deltaMoney, mType, payOrderData);
                iPaymentPresenter.submitOrder(context, mPayOrderData);
            }
        });

        /**
         * 手机短信支付
         */

        smsPayTextView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                // 0:盈华讯方
                LogProxy.i(TAG, "channel is " + payOrderData.getSmsRechargeChannel());
                String SmsRechargeChannel = "";
                if (PayTools.getInstance().getIsInsideUse()) {
                    SmsRechargeChannel = DomainUtility.getInstance().getSmsChannel(context);
                } else {
                    SmsRechargeChannel = payOrderData.getSmsRechargeChannel();
                }
                if (SmsRechargeChannel.equals("0")) {
                    // 盈华讯方短信支付方式界面
                    BaseActivityPage page = new DockSMSpayTypePage(context, manager, false, activity);
                    manager.addPage(page);
                }
            }
        });

        /**
         * 充值卡支付
         */
        rechargeCardPayTextView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                BaseActivityPage page = new PayRechargeCardView(context, manager, PaymentCenterView.this, false, activity);
                if (page != null) {
                    manager.addPage(page);
                }
            }
        });

        /**
         * 微信支付
         */
        rechargeWxPayTextView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (DeviceUtil.isAppInstalled(context, PaySysConstant.PAYMENT_WEIXINPAY_PACKAGE_NAME)) {

                    showProgressDialog();
                    mType = PaySysConstant.WXPAY_TYPE;
                    payTools.setCurrentType(mType);
                    PayOrderData mPayOrderData = payTools.getRequestParms(deltaMoney, mType, payOrderData);
                    iPaymentPresenter.submitOrder(context, mPayOrderData);
                } else {
                    String url = "market://details?id=" + PaySysConstant.PAYMENT_WEIXINPAY_PACKAGE_NAME;
                    UIUtil.showDownloadDialog(context, activity, url, Utility.getString(Resource.string.ft_payment_sdk_dock_dialog_to_download_weixin_title, context), Utility.getString(Resource
                            .string.ft_payment_sdk_dock_dialog_to_download_weixin_app_str, context), Utility.getString(Resource.string.ft_payment_sdk_dock_dialog_to_download_gonow_title, context),
                            Utility.getString(Resource.string.ft_payment_sdk_dock_dialog_btn_cancel_str, context));
                }
            }

        });
        /**
         * U币足够时支付
         */
        payBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if (payOrderData == null) {
                    LogProxy.d(TAG, "payOrderData is null");
                    return;
                }
                showProgressDialog();
                iPaymentPresenter.requestPay(context, payOrderData);
            }
        });
        /**
         * 银联支付
         */
        unionPayTextView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                mType = PaySysConstant.UNIONPAY_TYPE;
                PayOrderData mPayOrderData = payTools.getRequestParms(deltaMoney, mType, payOrderData);
                iPaymentPresenter.submitOrder(context, mPayOrderData);
            }
        });

    }


    @Override
    public boolean canBack() {
        return true;
    }

    @Override
    public void onResume() {
        //发送余额请求
        requestBlance();

        super.onResume();
    }

    public void requestBlance() {
        showProgressDialog();
        iPaymentPresenter.requestUBalance(context);
    }

    @Override
    public void setView() {
        boolean isOpenSmsPay;

        if (PayTools.getInstance().getIsInsideUse()) {
            isOpenSmsPay = FtSDKTools.getInstance().isOpenSmsPay && FtSDKTools.getInstance().isSDKOpenSmsPay;
        } else {
            isOpenSmsPay = PayTools.getInstance().getAppInfoBaseData().isOpenSmsPay();
        }

        if (isOpenSmsPay) {
            smsPayTextView.setVisibility(View.VISIBLE);
            smsPayGapLineLayout.setVisibility(View.VISIBLE);
        } else {
            smsPayTextView.setVisibility(View.GONE);
            smsPayGapLineLayout.setVisibility(View.GONE);
        }
        rechargeBtnLayout.setVisibility(View.GONE);
    }

    public void readerView() {
        String serverId = payOrderData.getServerId();
        String serverName = AppGameInfo.getInstance().getServerName();
        DecimalFormat df = new DecimalFormat("###.0");
        // TODO: 2017/4/20
        if (StringUtility.isEmpty(serverName)) {
            serverName = "";
        }
        String productName = payOrderData.getProductName();
        String account;
        boolean isBindMobile = false;
        if (PayTools.getInstance().getIsInsideUse()) {
            isBindMobile = FtSDKTools.getInstance().getBindMobile();
        } else {
            isBindMobile = PayTools.getInstance().getAppInfoBaseData().isBindMobile();
        }
        if (isBindMobile) {
            if (PayTools.getInstance().getIsInsideUse()) {
                account = BaseSdkTools.getInstance().getCurrentPassPort().getMobile();
            } else {
                account = PayTools.getInstance().getAppInfoBaseData().getMobile();
            }

        } else {
            if (PayTools.getInstance().getIsInsideUse()) {
                account = BaseSdkTools.getInstance().getCurrentPassPort().getPp();
            } else {
                account = PayTools.getInstance().getAppInfoBaseData().getPassPort();
            }
        }
        if (PayTools.getInstance().getIsInsideUse()) {
            mAppInfoTextView.setText(PayTools.getAppName(context) + "   " + serverName + "   " + productName);
            LogProxy.d(TAG, PayTools.getAppName(context) + "  " + serverId + " " + " " + serverName + " " + productName);
        } else {
            mAppInfoTextView.setText(PayTools.getInstance().getAppInfoBaseData().getAppName() + "   " + serverName + "   " + productName);
            LogProxy.d(TAG, PayTools.getInstance().getAppInfoBaseData().getAppName() + "  " + serverId + " " + " " + serverName + " " + productName);
        }
        chargeWarnProductName = productName;
        chargeWarnProducttPrice = payOrderData.getMoney() * PaySysConstant.PAY_RATIO;
        mProductPrice.setText(String.valueOf(df.format(payOrderData.getMoney() * PaySysConstant.PAY_RATIO)) + "  ");
        mPayUserInfo.setText(account + getString(Resource.string.ft_payment_sdk_pay_balance) + balance + "  " + getString(Resource.string.ft_payment_sdk_pay_unit));
        deltaMoney = (int) (payOrderData.getMoney() * PaySysConstant.PAY_RATIO - balance);
        if (deltaMoney <= 0) {// 可立即支付
            payBtn.setVisibility(View.VISIBLE);// 支付按钮可见
            payTypeLayout.setVisibility(View.GONE);// 充值方式按钮不见
            mTitle.setText(getString(Resource.string.ft_payment_sdk_dock_pay_center_balance_pay));// 标题设置为余额支付
            int payOrderMoney = (int) (payOrderData.getMoney() * PaySysConstant.PAY_RATIO);
            mMoneyForPay.setText(payOrderMoney + "  ");
        } else {// 显示充值界面入口
            payBtn.setVisibility(View.GONE);
            payTypeLayout.setVisibility(View.VISIBLE);
            mMoneyForPay.setText(deltaMoney + "  ");
            mTitle.setText(getString(Resource.string.ft_payment_sdk_dock_pay_center_balance_pay_need));
        }
    }

    @Override
    public void showError(String message, int errorCode) {
        dismissProgressDialog();
        LogProxy.d(TAG, message);
        eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_FAIL));
        BaseSdkTools.getInstance().dealErrorCode(context, message, errorCode, new ErrorCodeAction() {
            @Override
            public void doAction() {
                quit();
            }
        });
    }

    @Override
    public void showSuccess() {

    }

    /**
     * U币余额查询返回结果
     */
    @Override
    public void showResult(String data) {
        if (!StringUtility.isEmpty(data)) {
            balance = Integer.parseInt(data);// 返回结果
            dismissProgressDialog();
        }
        readerView();
    }

    /**
     * 支付宝、充值卡、手机短信、微信支付需要用到的支付信息payinfo
     * payinfo由 presenter回调返回
     *
     * @param payInfo 支付信息
     */
    @Override
    public void getPayInfo(String payInfo) {
        dismissProgressDialog();
        LogProxy.d(TAG, "submit order after payinfo" + payInfo);
        payTools.setPayInfo(payInfo);
        if (payTools.getCurrentType().equals(PaySysConstant.ALIPAY_TYPE)) {
            aliPay();
        } else if (payTools.getCurrentType().equals(PaySysConstant.WXPAY_TYPE)) {
            WeiChatPayUtil.startWxPay(context);
            activity.setNeedOpenDock(false);
            quit();
        }
    }

    /**
     * 支付宝支付
     */
    private void aliPay() {
        Runnable payRunnable = new Runnable() {
            @Override
            public void run() {
                // 构造PayTask 对象
                PayTask alipay = new PayTask(activity);
                // 调用支付接口，获取支付结果
                Map<String, String> resultParams = alipay.payV2(payTools.getPayInfo(), true);
                LogProxy.d(TAG, "payresult" + resultParams.toString());
                Message msg = new Message();
                msg.what = SDK_PAY_FLAG;
                msg.obj = resultParams;
                mHandler.sendMessage(msg);
            }
        };

        // 必须异步调用
        Thread payThread = new Thread(payRunnable);
        payThread.start();
        new Timer().schedule(new TimerTask() {

            @Override
            public void run() {
                dismissProgressDialog();
            }
        }, 0);
    }

    /**
     * 银联创建订单后返回的参数 用于银联第三方服务器验证
     *
     * @param tn         交易流水号
     * @param serverMode 银联支付环境 00-正式环境 01-测试环境
     */

    @Override
    public void getUnionInfo(String tn, String serverMode) {
        UPPayAssistEx.startPay(activity, null, null, tn, serverMode);

    }

    /**
     * U币支付成功后支付结果回调
     *
     * @param data 支付成功后剩余的U币数量
     */
    @Override
    public void getPayResult(String data, String msg) {
        dismissProgressDialog();
        ToastUtil.showMessage(context, msg, true);
        if (!data.equals("")) {
            eventBus.post(new BJMGFSdkEvent(BJMGFSdkEvent.RECHARGE_SUCCESS));
            quit();
        }
    }

}