package com.friendtimes.payment.utils.payment;

/**
 * Created by wutao on 2016/12/20.
 */

public class PaymentUtils {


}
