package com.friendtimes.payment.app.tools;

import android.content.Context;
import android.text.TextUtils;

import com.friendtime.foundation.bean.AppGameInfo;
import com.friendtime.foundation.bean.AppInfoData;
import com.friendtime.foundation.tools.BaseSdkTools;
import com.friendtime.foundation.utils.SpUtil;
import com.friendtime.foundation.utils.StringUtility;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.payment.config.PaySysConstant;
import com.friendtimes.payment.model.entity.AppInfoBaseData;
import com.friendtimes.payment.model.entity.PayOrderData;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by liwei002 on 2016/6/30.
 */
public class ParamsTools {

    private static final String TAG = ParamsTools.class.getSimpleName();

    private static ParamsTools paramsTools;
    private AppInfoBaseData appInfoBaseData = PayTools.getInstance().getAppInfoBaseData();
    private PayOrderData payOrderData = PayTools.getInstance().getPayOrderData();
    /**
     * 支付参数实体类的单例对象
     * @return
     */
    public static ParamsTools getInstance() {
        if (paramsTools == null) {
            synchronized (ParamsTools.class) {
                if (paramsTools == null) {
                    paramsTools = new ParamsTools();
                }
            }
        }
        return paramsTools;
    }

    /**
     * 网页支付所需要的参数
     * @param context
     * @return
     */
    public Map<String, String> getWapRecharge(Context context) {
        Map<String, String> params = getFoundationParamsMap(context);
        final String time = String.valueOf(System.currentTimeMillis());
        if(PayTools.getInstance().getIsInsideUse()){
            params.put("sign", StringUtility.md5(params.get("uuid") + AppInfoData.appId + time + AppInfoData.appKey + AppInfoData.APP_SECRET));
            params.put("payuserid", BaseSdkTools.getInstance().getCurrentPassPort().getUid());
        }else {
            params.put(
                    "sign",
                    StringUtility.md5(params.get("uuid") + appInfoBaseData.getAppId()
                            + time + appInfoBaseData.getAppKey()
                            + appInfoBaseData.getAppSecret()));
            params.put("payuserid", appInfoBaseData.getUid());
        }
        params.put("apporderno", payOrderData.getOrderSerial());
        params.put("money", payOrderData.getMoney() + "");
        params.put(
                "amount",
                String.valueOf((int) (payOrderData.getMoney() * PaySysConstant.PAY_RATIO)));
        params.put("vtime", time);
        params.put("userid", "");
        params.put("ext", payOrderData.getRoleId());
        params.put("sendurl", "");
        params.put("goodsname", payOrderData.getProductName());
        params.put("channel",appInfoBaseData.getChannel());
        return params;

    }

    /**
     * 充值创建订单参数
     * @param context
     * @param payOrderData
     * @return
     */
    public Map<String, String> getPaymentParamsMap(Context context,
                                                   PayOrderData payOrderData) {

        Map<String, String> params = getFoundationParamsMap(context);
        final String time = String.valueOf(System.currentTimeMillis());
        if(PayTools.getInstance().getIsInsideUse()){
            params.put("sign", StringUtility.md5(params.get("uuid") + AppInfoData.appId + time + AppInfoData.appKey + AppInfoData.APP_SECRET));
            params.put("channel", AppInfoData.getAdCode());
            if (AppInfoData.version != null) params.put("version", AppInfoData.version);
            params.put("payuserid", BaseSdkTools.getInstance().getCurrentPassPort().getUid());
        }else{
            params.put(
                    "sign",
                    StringUtility.md5(appInfoBaseData.getUuid() +appInfoBaseData.getAppId()
                            + time +appInfoBaseData.getAppKey()
                            + appInfoBaseData.getAppSecret()));
            params.put("channel", appInfoBaseData.getChannel());
            params.put("version", appInfoBaseData.getVersion());
            params.put("payuserid",appInfoBaseData.getUid());
        }

        params.put("apporderno", payOrderData.getOrderSerial() + "");
        params.put("money", payOrderData.getMoney() + "");
        params.put("amount", payOrderData.getAmount() + "");
        params.put("payid", payOrderData.getPayID());
        params.put("ext", payOrderData.getRoleId());
        params.put("sendurl", payOrderData.getRechargeUrl());
        params.put("goodsname", payOrderData.getProductName());
        params.put("cash", String.valueOf(payOrderData.getCash()));
        params.put("userid", "");
        params.put("extend", payOrderData.getExtend());
        params.put("ordertype", PaySysConstant.PAYMENT_ORDERTYPE);
        params.put("formatObjType", PaySysConstant.PAYMENT_FORMATOBJTYPE);

        params.put("appsid", payOrderData.getServerId() != null ? payOrderData.getServerId() : "088");
        params.put("vtime", time);
        params.put("extend2", "18661576287");
        return params;
    }

    /**
     * 余额足够支付时 支付所需参数
     * @param context   上下文
     * @param payOrderData  支付参数实体类
     * @return
     */
    public Map<String, String> getPayOrderParams(Context context,
                                                 PayOrderData payOrderData) {
      String time = String.valueOf(System.currentTimeMillis());
        Map<String, String> params = getFoundationParamsMap(context);
        if(PayTools.getInstance().getIsInsideUse()) {
            params.put("sign", StringUtility.md5(params.get("uuid") + AppInfoData.appId + time + AppInfoData.appKey + AppInfoData.APP_SECRET));
            params.put("channel", AppInfoData.getAdCode());
            params.put("appsid",AppGameInfo.getInstance().getServerId() != null ? AppGameInfo.getInstance().getServerId() : "088" );
            params.put("version", AppInfoData.getVersion());
        }else {
            params.put(
                    "sign",
                    StringUtility.md5(appInfoBaseData.getUuid() + appInfoBaseData.getAppId()
                            + time + appInfoBaseData.getAppKey()
                            + appInfoBaseData.getAppSecret()));
            LogProxy.i(TAG, AppInfoData.getUuid() + AppInfoData.getAppId()
                    + time + AppInfoData.getAppKey()
                    + AppInfoData.getAppSecret());
            params.put("channel",appInfoBaseData.getChannel());
            params.put("appsid",payOrderData.getServerId() != null ? payOrderData.getServerId() : "088" );
            params.put("version", appInfoBaseData.getVersion());
        }
        params.put("apporderno", payOrderData.getOrderSerial() + "");
        params.put("amount", payOrderData.getCount() + "");
        params.put("ext", payOrderData.getRoleId());
        params.put("sendurl", payOrderData.getRechargeUrl());
        params.put("goodsname", payOrderData.getProductName());
        params.put("cash", String.valueOf(payOrderData.getMoney()));
        params.put("ordertype", PaySysConstant.PAYMENT_ORDERTYPE);
        params.put("userid", "");
        params.put("extend", payOrderData.getExtend());
        params.put("ordertype", PaySysConstant.PAYMENT_ORDERTYPE);
        params.put("formatObjType", PaySysConstant.PAYMENT_FORMATOBJTYPE);
        params.put("vtime", time);
        params.put("serverid", payOrderData.getServerId() + "");
        return params;
    }

    /**
     * 基础参数
     * @param context 上下文
     * @return
     */
    public Map<String, String> getFoundationParamsMap(Context context) {
        HashMap <String, String>params = new HashMap();
        if(PayTools.getInstance().getIsInsideUse()){
            final String time = String.valueOf(System.currentTimeMillis());
            String uuid = SpUtil.getStringValue(context, "uuid", "");
            if (uuid != "") {
                params.put("uuid", uuid);
            }
            if (BaseSdkTools.getInstance().getCurrentPassPort() != null)
                params.put("token", BaseSdkTools.getInstance().getCurrentPassPort().getToken() == null ? "" : BaseSdkTools.getInstance().getCurrentPassPort().getToken());
            params.put("appid", AppInfoData.appId);
            params.put("platformid", AppInfoData.platformId);
            if (!TextUtils.isEmpty(AppInfoData.getAdCode())) params.put("channel", AppInfoData.getAdCode());

        }else {

            String uuid = appInfoBaseData.getUuid();
            if (uuid != "") {
                params.put("uuid", uuid);
            }

            if (appInfoBaseData.getToken() != null) {
                params.put("token", appInfoBaseData.getToken());
            }

            params.put("appid", appInfoBaseData.getAppId());
            params.put("platformid", appInfoBaseData.getPlatformId());
            LogProxy.d(TAG, "UUID =" + uuid + "token =" + appInfoBaseData.getToken() + "appid=" + appInfoBaseData.getAppId() + "platformid =" + appInfoBaseData.getPlatformId());
        }
            return params;
    }


}
