
package com.friendtimes.payment.ui.view;


import com.friendtimes.payment.ui.IBaseView;

public interface IPayRechargeCardViewNext extends IBaseView {
    //返回结果
    void showReturn(String msg);


	

}
