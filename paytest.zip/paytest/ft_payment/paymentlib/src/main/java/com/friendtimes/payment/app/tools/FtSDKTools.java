package com.friendtimes.payment.app.tools;

import android.content.Context;
import com.friendtime.foundation.tools.BaseSdkTools;
import com.friendtime.foundation.utils.Utility;

/**
 * Created by wutao on 2015/12/16.
 * 将配置SDK 属性 方法 独立至此类
 * ps.请后续开发者将配置SDK 属性 相关业务公共代码，放在此类中 ，
 */
public class FtSDKTools {

    private static final String TAG = FtSDKTools.class.getSimpleName();

    //屏幕方向 横屏 or 竖屏
    private int screenOrientation;

    //当前短信支付是否打开(游戏传入) .默认打开
    public boolean isOpenSmsPay = true;

    //短信支付是否打开（sdk传入）,默认打开
    public boolean isSDKOpenSmsPay = true;

    //是否启用支付回调 ，默认为false
    public boolean isOpenPayCallback;

    private static FtSDKTools bjmgfsdkTools;

    private FtSDKTools() {
    }

    public boolean isOpenPayCallback() {
        return isOpenPayCallback;
    }

    public void setOpenPayCallback(boolean openPayCallback) {
        isOpenPayCallback = openPayCallback;
    }

    public static FtSDKTools getInstance() {
        if (bjmgfsdkTools == null) {
            synchronized (FtSDKTools.class) {
                if (bjmgfsdkTools == null) {
                    bjmgfsdkTools = new FtSDKTools();

                }
            }
        }
        return bjmgfsdkTools;
    }


    /**
     * 得到屏幕方向
     *
     * @return
     */
    public int getScreenOrientation() {
        return screenOrientation;
    }

    /**
     * 设置当前游戏或应用的横竖屏参数
     *
     * @param screenOrientation BJMGF_Screen_Orientation_Landscape / BJMGF_Screen_Orientation_Portrait
     */
    public void setScreenOrientation(int screenOrientation) {
        this.screenOrientation = screenOrientation;
    }


    /**
     * 获得mac 地址，如果mac 地址为空 or  000000 时 ，那就取IMEI号
     * 此方法为
     *
     * @param context
     * @return
     */
    public String getBJMGFMac(Context context) {
        String macAddress = Utility.getMac(context);
        if (macAddress != "") {

            String[] macArrays = macAddress.split("\\D+");
            int sum = 0;
            for (String s : macArrays) {
                if (!s.equals(""))
                    sum += Integer.parseInt(s);
            }
            if (sum == 0) {
                macAddress = Utility.getDeviceIMEI(context);
            }
        }
        return macAddress;

    }
	public boolean getBindMobile() {
		return BaseSdkTools.getInstance().getCurrentPassPort() != null && BaseSdkTools.getInstance().getCurrentPassPort().getMobile() != null;
	}
}