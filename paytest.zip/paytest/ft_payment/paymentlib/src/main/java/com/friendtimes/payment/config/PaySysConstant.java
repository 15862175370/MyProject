package com.friendtimes.payment.config;

/**
 * Created by liwei002 on 2016/6/30.
 */
public class PaySysConstant {
    //充值卡充值url地址
    public static final String version = "201504181400?";

    //微信包名
    public static final String PAYMENT_WEIXINPAY_PACKAGE_NAME = "com.tencent.mm";

    // 屏幕方向
    public static final int BJMGF_Screen_Orientation_Landscape = 0;
    // 屏幕方向
    public static final int BJMGF_Screen_Orientation_Portrait = 1;

    public static final double PAY_RATIO = 10;        //充值渠道比例
    public static final int PAY_SMS_RATIO = 5;        //短代支付比例
    public static final int MAX_ALIPAY_MONEY = 5000;    //客户端支付宝充值最大金额

    /**
     * json key
     */
    //支付卡充值json文件
    public static final String PAYMENT_RECHARGE_CARDS_CONFIG = "rechargecardsConfig.json";
    // 好玩友CDN
    public static final String CDN_JSON_FILE_NAME = "BJGMSDK_CDN_JSON";
    public static final String netHeadForHttps = "https://";
    public static final String netHeadForHttp = "http://";
    /**
     * 支付类型
     */
    // 支付格式化OBJ
    public static final String PAYMENT_FORMATOBJTYPE = "object";
    // 消费类型参数
    public static final String PAYMENT_ORDERTYPE = "2";

    public static final String ALIPAY_TYPE = "115";        //115-支付宝无线快捷支付
    public static final String SMSPAY_TYPE = "116";        //116-大额短信支付SDK
    public static final String UNIONPAY_TYPE = "117";        //117-银联支付
    public static final String CM_CARD_PAY_TYPE = "111";    //111-移动卡支付
    public static final String CU_CARD_PAY_TYPE = "112";    //112-联通卡支付
    public static final String CT_CARD_PAY_TYPE = "113";    //113-电信卡支付
    public static final String WXPAY_TYPE = "118";        //118-微信支付


}
