package com.friendtimes.payment.ui.view.impl;

import android.app.Activity;
import android.content.Context;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.friendtime.foundation.tools.BaseSdkTools;
import com.friendtime.foundation.ui.activity.BJMGFActivity;
import com.friendtime.foundation.ui.page.BaseActivityPage;
import com.friendtime.foundation.ui.page.PageManager;
import com.friendtime.foundation.utils.BaseDomainUtility;
import com.friendtime.foundation.utils.ReflectResourcer;
import com.friendtime.foundation.utils.StringUtility;
import com.friendtime.foundation.utils.ToastUtil;
import com.friendtime.foundation.utils.Utility;
import com.friendtimes.ft_eventbus.EventBus;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.ft_tipsdialog.ReflectResourceId;
import com.friendtimes.payment.app.FtPaymentSdk;
import com.friendtimes.payment.app.tools.FtSDKTools;
import com.friendtimes.payment.app.tools.PayTools;
import com.friendtimes.payment.config.PaySysConstant;
import com.friendtimes.payment.event.PaymentEvent;
import com.friendtimes.payment.model.entity.PayOrderData;
import com.friendtimes.payment.presenter.IPaymentPresenter;
import com.friendtimes.payment.presenter.impl.PaymentPresenterImpl;
import com.friendtimes.payment.ui.view.IPaymentView;
import com.friendtimes.payment.utils.Resource;
import com.friendtimes.payment.widget.dialog.BJMSdkDialog;
import com.vsofo.vsofopay.SDKAPI;
import com.vsofo.vsofopay.util.IPayResultCallback;


/**
 * 盈华短信充值
 *
 * @author zhouhonghai
 */
public class DockSMSpayTypePage extends BaseActivityPage implements IPaymentView, IPayResultCallback, OnClickListener {

    private static String TAG = DockSMSpayTypePage.class.getSimpleName();

    /**
     * 视图控件
     */
    private RelativeLayout mBackLayout = null;
    private TextView goodDescription = null;    //描述
    private TextView rechargePrompt = null;        //充值前提示语
    private Button rechargeAndPayBtn = null;    //充值并支付按钮
    private TextView payTextView_5, payTextView_10, payTextView_15, payTextView_20, payTextView_30;
    private TextView smsNoticeTextView, mDesc;

    private IPaymentPresenter iPaymentPresenter;
    private PayOrderData payOrderData;        //订单数据
    private String spurl = "";        //商户服务器交互地址
    private String goods = "";        //所购物品描述
    private String smsNotice = "";
    private int cash = 0;        //用户所选的充值金额
    private double deltaMoney;
    private int balance;
    private boolean isRecharge = false;
    private PayTools mPayTools;
    private EventBus eventBus;

    public DockSMSpayTypePage(Context context, PageManager manager, boolean isRecharge, BJMGFActivity activity) {
        super(ReflectResourcer.getLayoutId(context, Resource.layout.ft_payment_sdk_dock_recharge_sms_page), context, manager, activity);
        this.isRecharge = isRecharge;
        this.mPayTools = PayTools.getInstance();
        this.payOrderData = mPayTools.getPayOrderData();
        iPaymentPresenter = new PaymentPresenterImpl(context, this);
        eventBus = EventBus.getDefault();
    }

    @Override
    public void onCreateView(View view) {

        mBackLayout = (RelativeLayout) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_closeLlId));
        goodDescription = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_recharge_goodsStrId));

        // 运营商短代支付渠道关闭时，给用户提示
        smsNotice = BaseDomainUtility.getInstance().getSmsNotice(context);
        smsNoticeTextView = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_notice_layoutId));
        if (smsNotice.equals("0") || smsNotice.equals("") || smsNotice.isEmpty()) {
            smsNoticeTextView.setVisibility(View.GONE);
        } else {
            smsNoticeTextView.setText(smsNotice);
            smsNoticeTextView.setVisibility(View.VISIBLE);
        }

        mDesc = (TextView) view
                .findViewById(ReflectResourcer
                        .getViewId(
                                context,
                                Resource.id.ft_payment_sdk_dock_recharge_sms_promptStrId_three));

        mDesc.setText(String.format(Utility.getString(Resource.string.ft_payment_sdk_dock_recharge_sms_pay_prompt_warn_three,context), TextUtils.isEmpty(FtPaymentSdk.getDefault().getPublicNumberForPay()) ? "800057851" : FtPaymentSdk.getDefault().getPublicNumberForPay()));


        rechargePrompt = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_recharge_promptId));

        rechargeAndPayBtn = (Button) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_buybtnId));

        mBackLayout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (StringUtility.isEmpty(mPayTools.getPayInfo())) {// 如果创建过订单
                    goBack();
                } else {// 回到应用
                    mPayTools.clearPayDatas();// 清除订单信息
                    quit();
                }
            }
        });

        rechargeAndPayBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                LogProxy.i(TAG, "click recharge a");
                if (cash <= 0) {
                    ToastUtil.showMessage(context, getString(Resource.string.ft_payment_sdk_dock_recharge_pleaseChooseMoney));
                    return;
                }
                if (!Utility.isHaveSimCard(context)) {
                    ToastUtil.showMessage(context, getString(Resource.string.ft_payment_sdk_no_sim_card));
                    return;
                }
                payOrderData = mPayTools.getPayOrderData();
                if (payOrderData == null) {
                    LogProxy.i(TAG, "payOrderDataa is null");
                    quit();
                    return;
                }
                payOrderData.setCash(cash);
                payOrderData.setMoney(cash * 2);
                payOrderData.setAmount((int) (payOrderData.getCash() * 2 * PaySysConstant.PAY_SMS_RATIO));
                payOrderData.setPayID(PaySysConstant.SMSPAY_TYPE);
               /* rechargeOrderDetail = new RechargeOrderDetail(
                          payOrderData.getAppOrderNumber(),
                          cash,
                          payOrderData.getCash() * 2,
                          (int) (payOrderData.getCash() * 2 * PaySysConstant.PAY_SMS_RATIO),
                          payOrderData.getUserID(), payOrderData.getExt(),
                          payOrderData.getSendUrl(), payOrderData.getChannel(),
                          payOrderData.getAppServerID(),
                          payOrderData.getExtend(), payOrderData.getOrderType(),
                          "18656508068", PaySysConstant.SMSPAY_TYPE,//##
                          payOrderData.getProductName());*/
                if (isRecharge) {
                    payOrderData.setMoney((int) cash);
                    payOrderData.setAmount((int) cash * PaySysConstant.PAY_SMS_RATIO);
                }
                mPayTools.setPayOrderData(payOrderData);
                LogProxy.i(TAG, "click recharge");
                sendRechargeRequest();
            }
        });

        createPrice(view);

        if (isRecharge) {
            rechargePrompt.setVisibility(View.GONE);
        } else {
            rechargePrompt.setVisibility(View.VISIBLE);
        }
        super.onCreateView(view);
    }

    /**
     * 选择既定价格
     *
     * @param view
     */
    private void createPrice(View view) {
        payTextView_5 = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_price_5_Id));
        payTextView_10 = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_price_10_Id));
        payTextView_15 = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_price_15_Id));
        payTextView_20 = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_price_20_Id));
        payTextView_30 = (TextView) view.findViewById(ReflectResourcer.getViewId(context, Resource.id.ft_payment_sdk_dock_recharge_sms_price_30_Id));

        payTextView_5.setOnClickListener(this);
        payTextView_10.setOnClickListener(this);
        payTextView_15.setOnClickListener(this);
        payTextView_20.setOnClickListener(this);
        payTextView_30.setOnClickListener(this);

        if (isRecharge) {    //##if (isRecharge && !ft_paymentData.isPlatform()) {
            LogProxy.i(TAG, "aaaaaaa");
            refreshViewByCashValue(0);
        } else {
            LogProxy.i(TAG, "bbbbbbbb");
            setDefaultRechargePrice();
        }
    }

    /**
     * 默认选中充值金额元
     */
    private void setDefaultRechargePrice() {
        if (deltaMoney <= 5 * PaySysConstant.PAY_SMS_RATIO && deltaMoney > 0) {
            selectedPrice(payTextView_5);
        } else if (deltaMoney <= 10 * PaySysConstant.PAY_SMS_RATIO && deltaMoney > 5 * PaySysConstant.PAY_SMS_RATIO) {
            selectedPrice(payTextView_10);
        } else if (deltaMoney <= 15 * PaySysConstant.PAY_SMS_RATIO && deltaMoney > 10 * PaySysConstant.PAY_SMS_RATIO) {
            selectedPrice(payTextView_15);
        } else if (deltaMoney <= 20 * PaySysConstant.PAY_SMS_RATIO && deltaMoney > 10 * PaySysConstant.PAY_SMS_RATIO) {
            selectedPrice(payTextView_20);
        } else {
            selectedPrice(payTextView_30);
        }
    }

    private void selectedPrice(TextView textView) {
        resetPriceLayout(textView, false);
    }

    /**
     * 恢复价格设置状态
     *
     * @param textView       当前选中的既定价格
     * @param isEditSelected 当前选中的是否是EditText
     */
    private void resetPriceLayout(TextView textView, boolean isEditSelected) {
        unselectAllPrice();
        if (!isEditSelected) {
            textView.setBackgroundResource(ReflectResourcer.getDrawableId(context, Resource.mipmap.ft_payment_sdk_recharge_item_selected_bg));
            textView.setTextColor(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_white)));
            if (!StringUtility.isEmpty(textView.getText().toString())) {
                String str = textView.getText().toString();
                cash = Integer.parseInt(str.substring(0, str.length() - 1));
            }
        } else {
            cash = 0;
        }
        if (cash >= 0) {
            LogProxy.i(TAG, "bbbbbbb");
            refreshViewByCashValue(cash);
        }
        mPayTools.setPayInfo("");// 充值金额变化 重新请求订单
    }

    /**
     * 根据充值金额 设置页面显示
     *
     * @param money 用户输入的充值金额
     */
    private void refreshViewByCashValue(int money) {
        LogProxy.i(TAG, "money is " + money);
        if (payOrderData == null) {
            LogProxy.i(TAG, "payOrderDatac is null");
            quit();
            return;
        }
        // 充值后账户增加的平台币数量
        String sCashFormat = getString(Resource.string.ft_payment_sdk_dock_recharge_goods_countStr);
        String sFinalStr = String.format(sCashFormat, money * PaySysConstant.PAY_SMS_RATIO);
        goodDescription.setText(sFinalStr);
        setPriceTitleColor(sFinalStr, goodDescription);
        if (!isRecharge) {
            // 提示语变更
            int leftMooney = (int) ((balance + money * PaySysConstant.PAY_SMS_RATIO) - payOrderData.getCash() * PaySysConstant.PAY_RATIO);
            if (leftMooney > 0) {
                String sbalanceFormat = getString(Resource.string.ft_payment_sdk_dock_recharge_prompt_paymoreStr);
                String str = String.format(sbalanceFormat, leftMooney);
                rechargePrompt.setText(str);
            } else if (leftMooney < 0) {
                rechargePrompt.setText(getString(Resource.string.ft_payment_sdk_dock_recharge_prompt_paylessStr));
            } else {
                rechargePrompt.setText("");
            }
            if (cash == 0) {
                rechargePrompt.setText("");
            }
        }
    }

    /**
     * 设置文字颜色
     *
     * @param sFinalStr
     * @param textView
     */
    private void setPriceTitleColor(String sFinalStr, TextView textView) {
        SpannableStringBuilder builder = new SpannableStringBuilder(sFinalStr);
        ForegroundColorSpan priceSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_textgray)));
        builder.setSpan(priceSpan, 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(builder);
    }

    /**
     * 发送充值请求
     */
    private void sendRechargeRequest() {
        if (payOrderData == null) {
            LogProxy.i(TAG, "send recharge a");
            LogProxy.i(TAG, "payOrderDatad is null");
            quit();
            return;
        }
        if (!isRecharge) {
            double leftMoney = (balance + cash * PaySysConstant.PAY_SMS_RATIO) - payOrderData.getCash() * PaySysConstant.PAY_RATIO;
            if (leftMoney < 0) {
                showPayConfirmDialog();
                return;
            }
        }

        LogProxy.d(TAG, "cash=" + cash);
        doPay();
    }

    /**
     * Dialog请用户确认支付 当用户选择的金额 不足以支付订单时弹出
     */
    private void showPayConfirmDialog() {
        LogProxy.i(TAG, "open dialog");
        try {
            final BJMSdkDialog dialog = new BJMSdkDialog(activity);
            dialog.setTitle(getString(Resource.string.ft_payment_sdk_dock_pay_center_dialog_title_str));
            dialog.setMessage(getString(Resource.string.ft_payment_sdk_dock_recharge_prompt_paylessStr));
            dialog.setNegativeButton(getString(Resource.string.ft_payment_sdk_dock_dialog_btn_cancel_str), new OnClickListener() {

                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            dialog.setPositiveButton(getString(Resource.string.ft_payment_sdk_dock_dialog_btn_ok_str), new OnClickListener() {

                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    doPay();
                }
            });
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
            LogProxy.i(TAG, "dialog is error");
        }
    }

    private void doPay() {
        //setRequestParams();
        // GFHelpler.smsRechargeOrderSDK();
        showProgressDialog();
        iPaymentPresenter.startSmsPay(context, payOrderData);
    }

    /**
     * 短信支付接口
     */
    protected void smsPay() {
        try {
            spurl = mPayTools.getPayInfo();
            goods = cash * PaySysConstant.PAY_SMS_RATIO + getString(Resource.string.ft_payment_sdk_dock_pay_center_unitStr);
            // Log.d("1", "goods:" + goods + " spurl" + spurl);
            // spurl = spurl + "&mz=" + cash;
            LogProxy.d(TAG, "goods=" + goods + "\nspurl=" + spurl);
            LogProxy.i(TAG, "activity is " + activity.toString());
            Activity a = activity.getParent();
            if (a == null) {
                a = activity;
            }
            LogProxy.d(TAG, "spurl=" + spurl);
            SDKAPI.startPay(a, spurl, goods, DockSMSpayTypePage.this);
            mPayTools.clearPayDatas();
        } catch (Exception e) {
            e.printStackTrace();
            LogProxy.i(TAG, "smsPay error");
        }
    }

    /**
     * 取消所有价格的选中状态
     */
    private void unselectAllPrice() {
        resetTextViewStatus(payTextView_5);
        resetTextViewStatus(payTextView_10);
        resetTextViewStatus(payTextView_15);
        resetTextViewStatus(payTextView_20);
        resetTextViewStatus(payTextView_30);
    }

    private void resetTextViewStatus(TextView textView) {
        textView.setBackgroundResource(ReflectResourcer.getDrawableId(context, Resource.drawable.ft_payment_sdk_text_with_roundcorner_selector));
        textView.setTextColor(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_black)));
    }

    @Override
    public void setView() {

    }

    @Override
    public void onClick(View v) {
        if (v.equals(payTextView_5)) {
            selectedPrice(payTextView_5);
        } else if (v.equals(payTextView_10)) {
            selectedPrice(payTextView_10);
        } else if (v.equals(payTextView_20)) {
            selectedPrice(payTextView_20);
        } else if (v.equals(payTextView_30)) {
            selectedPrice(payTextView_30);
        } else if (v.equals(payTextView_15)) {
            selectedPrice(payTextView_15);
        }
    }

    @Override
    public void showError(String message, int errorCode) {
        dismissProgressDialog();
        BaseSdkTools.getInstance().dealErrorCode(context, message, errorCode);
    }

    @Override
    public void showSuccess() {

    }

    @Override
    public void showResult(String data) {

    }

    @Override
    public void getPayInfo(String payInfo) {
        dismissProgressDialog();
        LogProxy.i(TAG, "payInfo:" + payInfo);
        mPayTools.setPayInfo(payInfo);
        smsPay();
    }

    @Override
    public void getUnionInfo(String tn, String serverMode) {

    }

    @Override
    public void getPayResult(String data, String msg) {

    }

    @Override
    public void onPayResult(int i, String s, String s1) {
        dismissProgressDialog();
        activity.setNeedOpenDock(false);
        spurl = "";
        goods = "";
        if (100 == i) {
            LogProxy.i("1--传入状态说明:", "100短信成功等待扣费中 ");
            LogProxy.i("2--说明数据是:", s);
            LogProxy.i("3--商户唯一订单号:", s1);
            s = "支付请求已提交，请返回账户查询余额。";
            if (FtSDKTools.getInstance().isOpenPayCallback()) eventBus.post(new PaymentEvent(PaymentEvent.SMS_PAY_SUCCESS));
            ToastUtil.showMessage(activity, s);
        } else if (101 == i) {
            LogProxy.i("1--传入状态数据是i:", "是101代表该手机不能支付 ");
            LogProxy.i("2--说明数据是:", s);
            LogProxy.i("3--商户唯一订单号:", s1);
            if (FtSDKTools.getInstance().isOpenPayCallback()) eventBus.post(new PaymentEvent(PaymentEvent.SMS_PAY_FAIL));
            s = "该手机不能支付";
            ToastUtil.showMessage(activity, s);
        } else if (102 == i) {
            LogProxy.i("1--传入状态数据是i:", "是102代表该手动模式 ");
            LogProxy.i("2--说明数据是:", s);
            LogProxy.i("3--商户唯一订单号:", s1);
            if (FtSDKTools.getInstance().isOpenPayCallback()) eventBus.post(new PaymentEvent(PaymentEvent.SMS_PAY_FAIL));
            ToastUtil.showMessage(activity, s);
        } else if (103 == i) {
            LogProxy.i("1--传入状态数据是i:", "是103需要用户去短信箱子收短信 回复确认 或 移动限制了 ");
            LogProxy.i("2--说明数据是:", s);
            LogProxy.i("3--商户唯一订单号:", s1);
            // s="请到收件箱接收短信，并回复确认支付。";
            s = "支付失败,未产生任何费用。";
            if (FtSDKTools.getInstance().isOpenPayCallback()) eventBus.post(new PaymentEvent(PaymentEvent.SMS_PAY_FAIL));
            showResultDialog(s + "\n订单号：" + s1);
            return;
        } else if (104 == i) {
            LogProxy.i("1--传入状态数据是i:", "104数据异常了 ");
            LogProxy.i("2--说明数据是:", s);
            LogProxy.i("3--商户唯一订单号:", s1);
            if (FtSDKTools.getInstance().isOpenPayCallback()) eventBus.post(new PaymentEvent(PaymentEvent.SMS_PAY_FAIL));
            // 处理该订单的业务逻辑。
            // Toast.makeText(activity, s,
            // Toast.LENGTH_LONG).show();
        } else if (109 == i) {
            LogProxy.i("1--传入状态数据是i:", "用户退出支付了 ");
            LogProxy.i("2--说明数据是:", s);
            LogProxy.i("3--商户唯一订单号:", s1);
            if (FtSDKTools.getInstance().isOpenPayCallback()) eventBus.post(new PaymentEvent(PaymentEvent.SMS_PAY_FAIL));
            // 处理该订单的业务逻辑。
            s = "用户已取消支付";
            ToastUtil.showMessage(activity, s);
        }
        showResultDialog(s + "\n订单号：" + s1);
        LogProxy.d(TAG, "message id= " + i + ": s= " + s + ": s1= " + s1);
    }

    private void showResultDialog(String resultMsg) {
        final BJMSdkDialog dialog = new BJMSdkDialog(context);
        dialog.setTitle(getString(Resource.string.ft_payment_sdk_dock_pay_center_smsPayStr));
        dialog.setMessage(resultMsg);
        dialog.setPositiveButton(getString(Resource.string.ft_payment_sdk_dock_dialog_btn_ok_str), new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                quit();
            }
        });
        try {
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
            LogProxy.i(TAG, "show error");
        }

    }

}
