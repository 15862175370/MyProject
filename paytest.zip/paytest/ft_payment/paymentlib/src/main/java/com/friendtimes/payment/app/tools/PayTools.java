package com.friendtimes.payment.app.tools;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.friendtime.foundation.bean.AppInfoData;
import com.friendtime.foundation.bean.PassPort;
import com.friendtime.foundation.utils.ReflectResourcer;
import com.friendtime.foundation.utils.StringUtility;
import com.friendtimes.payment.config.PaySysConstant;
import com.friendtimes.payment.model.entity.AppInfoBaseData;
import com.friendtimes.payment.model.entity.PayOrderData;
import com.friendtimes.payment.model.entity.RechargeCard;
import com.friendtimes.payment.model.entity.RechargeCardDetailData;
import com.friendtimes.payment.ui.view.impl.PayRechargeCardView;
import com.friendtimes.payment.ui.view.impl.PayRechargeCardViewNext;
import com.friendtimes.payment.utils.Resource;

import java.util.ArrayList;

/**
 * Created by liwei002 on 2016/6/30.
 */
public class PayTools {
    //是否打开短信充值
    private boolean isOpenSmsPay = true;
    //是否绑定手机
    private boolean isBindMobile = false;
    public static final int ORDER_TYPE_RECHARGE = 1;
    public static final int ORDER_TYPE_RECHARGE_PAY = ORDER_TYPE_RECHARGE + 1;
    private String orderType = "2";        //订单类型(不能为空)【1 - 正常充值平台币;2 - 充值并消费平台币(手游)】
    private String payInfo = "";    //支付宝支付传入参数
    private String mCurrentType;
    private static PayTools payTools;
    private AppInfoData appInfo;
    public String rechargeCardUrl;
    public String basePaymentDomainUrl;
    public String webRechargeUrl;
    private AppInfoBaseData appInfoBaseData;
    public PassPort currentPassPort = null;
    private boolean isWapRecharge = false;
    //判断该组件是自己项目调用还是社交平台调用 ，默认为自己项目调用
    private boolean isInsideUse = true;
    // 用户账户余额足够支付订单的数据类(用应用传入的订单数据对其各个属性赋值)
    private PayOrderData payOrderData;
    // 充值卡信息类
    private ArrayList<RechargeCardDetailData> rechargeCardsInfo;

    public static PayTools getInstance() {
        if (payTools == null) {
            synchronized (PayTools.class) {
                if (payTools == null) {
                    payTools = new PayTools();
                }
            }
        }
        return payTools;
    }

    public void setCurrentType(String type) {
        this.mCurrentType = type;
    }

    public String getCurrentType() {
        return mCurrentType;
    }

    public void setPayOrderData(PayOrderData payOrderData) {
        this.payOrderData = payOrderData;
    }

    public PayOrderData getPayOrderData() {
        return payOrderData;
    }

    /**
     * 清除支付相关信息
     */
    public void clearPayDatas() {
        setPayOrderData(null);
        setPayOrderData(null);
        setPayInfo("");

    }

    public String getPayInfo() {
        return payInfo;
    }

    public void setPayInfo(String payInfo) {
        this.payInfo = payInfo;

    }

    /**
     * 充值参数数据类
     *
     * @param deltaMoney 充值金额
     * @param mType      支付类型
     * @param orderData  支付数据类
     * @return
     */
    public PayOrderData getRequestParms(int deltaMoney, String mType, PayOrderData orderData) {
        double money = deltaMoney / PaySysConstant.PAY_RATIO;
        payOrderData.setCash(money);
        payOrderData.setPayID(mType);
        return payOrderData;

    }

    /**
     * 充值卡数据类获得
     */
    public String[] getRechargeCardInfo(ArrayList<RechargeCardDetailData> list) {
        String[] operatorsName = new String[list.size()];
        for (int i = 0; i < operatorsName.length; i++) {
            operatorsName[i] = list.get(i).tip;
        }
        return operatorsName;
    }

    /**
     * 充值卡支付
     * 判断用户输入的卡号长度是否合法
     *
     * @return true:合法 可以提交请求
     */
    public static boolean checkCardNoLength(RechargeCard rechargeCard, EditText cardNoEditText) {
        if (StringUtility.isEmpty(cardNoEditText.getText().toString()) || cardNoEditText.getText().length() != rechargeCard.cardNumberLength) {
            return false;
        }
        return true;
    }

    /**
     * 充值卡支付
     * 判断用户输入的密码长度是否合法
     *
     * @return true:合法 可以提交请求
     */
    public static boolean checkCardPwLength(RechargeCard rechargeCard, EditText cardPWEditText) {
        if (StringUtility.isEmpty(cardPWEditText.getText().toString()) || cardPWEditText.getText().length() != rechargeCard.cardPwdLength) {
            return false;
        }
        return true;
    }

    /**
     * 设置用户充值信息
     *
     * @param context                 上下文
     * @param payRechargeCardViewNext
     * @param rechargeCard            充值卡类
     * @param selectedInfoTextView    用户所选金额显示
     * @param cash                    用户所选金额
     */
    public void setSelectedInfoTextViewStr(final Context context, PayRechargeCardViewNext payRechargeCardViewNext, RechargeCard rechargeCard, TextView selectedInfoTextView, int cash) {
        String part1 = payRechargeCardViewNext.getString(Resource.string.ft_payment_sdk_dock_recharge_cardPay_next_chose_str);
        String part2 = payRechargeCardViewNext.getString(Resource.string.ft_payment_sdk_dock_recharge_cardPay_next_recharge_str);
        String unit = payRechargeCardViewNext.getString(Resource.string.ft_payment_sdk_dock_recharge_cardPay_yuan_space_unit_str);
        String selectedStr = part1 + rechargeCard.name + part2 + cash + unit;
        SpannableStringBuilder builder = new SpannableStringBuilder(selectedStr);
        ForegroundColorSpan titleSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_black)));
        ForegroundColorSpan nameSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_text_wish_role_color)));
        ForegroundColorSpan unitSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_text_wish_role_color)));
        ForegroundColorSpan priceSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_text_wish_role_color)));
        int index0 = part1.length();
        int index1 = part1.length() + rechargeCard.name.length();
        int index2 = part1.length() + rechargeCard.name.length() + part2.length();
        int index3 = part1.length() + rechargeCard.name.length() + part2.length() + String.valueOf(cash).length();
        builder.setSpan(titleSpan, 0, index0, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.setSpan(nameSpan, index0, index1, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        builder.setSpan(titleSpan, index1, index2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.setSpan(priceSpan, index2, index3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.setSpan(unitSpan, index3, builder.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        selectedInfoTextView.setText(builder);
    }

    /**
     * 设置文字颜色
     *
     * @param sFinalStr 充值金额
     * @param textView  充值金额文本框
     */
    private void setPriceTitleColor(String sFinalStr, TextView textView, Context context) {
        SpannableStringBuilder builder = new SpannableStringBuilder(sFinalStr);
        ForegroundColorSpan priceSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_textgray)));
        builder.setSpan(priceSpan, 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(builder);
    }

    /**
     * 显示用户支付后剩余的U币数
     *
     * @param context                 上下文
     * @param money                   用户支付金额
     * @param payRechargeCardViewNext 充值卡界面
     * @param goodDescriptionUnit
     * @param goodDescription         商品描述
     * @param balance                 余额
     * @param payOrderData            支付数据
     * @param cash                    用户充值金额
     * @param rechargePrompt          充值提示语
     */
    public void cardNextrefreshViewByCash(final Context context, int money, PayRechargeCardViewNext payRechargeCardViewNext, final TextView goodDescriptionUnit, final TextView goodDescription, int
            balance, PayOrderData payOrderData, int cash, TextView rechargePrompt) {
        String sCashFormat = payRechargeCardViewNext.getString(Resource.string.ft_payment_sdk_dock_recharge_goods_countStr);
        String sFinalStr = String.format(sCashFormat, (int) (money * PaySysConstant.PAY_RATIO));
        goodDescriptionUnit.setVisibility(View.VISIBLE);
        goodDescription.setVisibility(View.VISIBLE);
        setPriceTitleColor(sFinalStr, goodDescription, context);
        int leftMoney = (int) (balance + money * PaySysConstant.PAY_RATIO - payOrderData.getCash() * PaySysConstant.PAY_RATIO);
        if (leftMoney >= 0) {
            String sbalanceFormat = payRechargeCardViewNext.getString(Resource.string.ft_payment_sdk_dock_recharge_prompt_paymoreStr);
            String str = String.format(sbalanceFormat, leftMoney);
            //支付结余
            rechargePrompt.setText(str);

        } else if (leftMoney < 0) {
            rechargePrompt.setText(payRechargeCardViewNext.getString(Resource.string.ft_payment_sdk_dock_recharge_prompt_paylessStr));
        } else {
            rechargePrompt.setText("");
        }
        if (cash == 0) {
            rechargePrompt.setText("");
        }
    }

    /**
     * 获得支付所需数据
     *
     * @param payOrderData 支付数据类
     * @param payid        充值卡类型id
     * @param extendStr    支付数据
     * @param cash         用户所选金额
     * @return
     */
    public PayOrderData getRechargeOrderDEtailDta(PayOrderData payOrderData, String payid, String extendStr, int cash) {
        payOrderData.setPayID(payid);
        payOrderData.setExtend(extendStr);
        payOrderData.setCash(cash);
        /*RechargeOrderDetail rechargeOrderDetail = new RechargeOrderDetail(payOrderData.getAppOrderNumber(),
                  payOrderData.getCash(), cash, (int) (cash * PaySysConstant.PAY_RATIO), payOrderData.getUserID(),
                  payOrderData.getExt(), payOrderData.getRechargeUrl(), appInfoBaseData.getChannel(),
                payOrderData.getServerId(), extendStr, payOrderData.getOrderType(),
                  "", payid, payOrderData.getProductName());*/
        return payOrderData;
    }

    /**
     * 设置U币
     *
     * @param money               需要支付的金额
     * @param payRechargeCardView 充值界面
     * @param context             上下文
     * @param goodDescription     商品描述
     */
    public void refreshViewByCash(int money, PayRechargeCardView payRechargeCardView, final Context context, TextView goodDescription) {
        String rechargeCashStr = payRechargeCardView.getString(Resource.string.ft_payment_sdk_dock_recharge_goods_countStr);
        String rechargeCash = String.format(rechargeCashStr, (int) (money * PaySysConstant.PAY_RATIO));
        String unit = payRechargeCardView.getString(Resource.string.ft_payment_sdk_dock_pay_center_unitStr);
        goodDescription.setVisibility(View.VISIBLE);
        SpannableStringBuilder builder = new SpannableStringBuilder(rechargeCash + unit);
        //ForegroundColorSpan 为文字前景色，BackgroundColorSpan为文字背景色
        ForegroundColorSpan titleSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_textgray)));
        ForegroundColorSpan unitSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_textgray)));
        ForegroundColorSpan priceSpan = new ForegroundColorSpan(context.getResources().getColor(ReflectResourcer.getColorId(context, Resource.color.ft_payment_sdk_text_price_color)));
        builder.setSpan(titleSpan, 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.setSpan(priceSpan, 5, rechargeCash.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        builder.setSpan(unitSpan, rechargeCash.length(), builder.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        builder.setSpan(new AbsoluteSizeSpan(16, true), 0, rechargeCash.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.setSpan(new AbsoluteSizeSpan(12, true), rechargeCash.length(), builder.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        goodDescription.setText(builder);


    }

    public String getRechargeCardUrl() {
        return rechargeCardUrl;
    }

    public void setRechargeCardUrl(String rechargeCardUrl) {
        this.rechargeCardUrl = rechargeCardUrl;
    }

    public String getBasePaymentDomainUrl() {
        return basePaymentDomainUrl;
    }

    public void setBasePaymentDomainUrl(String basePaymentDomainUrl) {
        this.basePaymentDomainUrl = basePaymentDomainUrl;
    }

    public String getWebRechargeUrl() {
        return webRechargeUrl;
    }

    public void setWebRechargeUrl(String webRechargeUrl) {
        this.webRechargeUrl = webRechargeUrl;
    }

    /**
     * 设置AppInfo基础参数
     *
     * @param appInfoBaseData
     */
    public void setAppInfoBaseData(AppInfoBaseData appInfoBaseData) {
        this.appInfoBaseData = appInfoBaseData;
    }

    /**
     * 获得APPInfo基础参数
     *
     * @return
     */
    public AppInfoBaseData getAppInfoBaseData() {
        return appInfoBaseData;
    }

    public PassPort getCurrentPassPort() {
        return this.currentPassPort;
    }

    public void setCurrentPassPort(PassPort currentPassPort) {
        this.currentPassPort = currentPassPort;
    }

    /**
     * 设置是否为网页充值
     *
     * @param isWapRecharge
     */
    public void setIsWapRecharge(boolean isWapRecharge) {
        this.isWapRecharge = isWapRecharge;
    }

    public boolean getIsWapRecharge() {
        return isWapRecharge;
    }

    //以下方法用于判断此接口是否为社交平台调用
    public void setIsInsideUse(boolean isInsideUse) {
        this.isInsideUse = isInsideUse;

    }

    public boolean getIsInsideUse() {
        return isInsideUse;
    }

    /**
     * 获取应用名
     *
     * @param context
     * @return
     */
    public static String getAppName(Context context) {
        PackageManager packageManager = null;
        ApplicationInfo applicationInfo = null;
        try {
            packageManager = context.getApplicationContext().getPackageManager();
            applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
            String applicationName = (String) packageManager.getApplicationLabel(applicationInfo);
            return applicationName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

}
