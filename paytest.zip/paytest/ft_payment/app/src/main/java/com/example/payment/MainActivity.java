package com.example.payment;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.ftpayment.R;
import com.friendtime.foundation.bean.PassPort;
import com.friendtime.foundation.event.BJMGFSdkEvent;
import com.friendtime.foundation.tools.BaseSdkTools;
import com.friendtimes.ft_logger.LogProxy;
import com.friendtimes.payment.app.FtPaymentSdk;
import com.friendtimes.payment.event.FtPaymentCallback;
import com.friendtimes.payment.model.entity.AppInfoBaseData;
import com.friendtimes.payment.model.entity.PayOrderData;

/**
 * 支付组件测试工程
 * 调起支付组件，需要向支付组件传递如下 参数
 * uid   用户Id
 * token  当前用户 token
 * orderSerial 订单号
 * productId 商品Id
 * productName  商品名称
 * count  商品件数
 * money 商品总价
 * serverId 服务器Id
 * roleId  角色Id
 * rechargeUrl  充值回调URL 可为空
 * rechargeChannel 充值渠道  可写为0
 * appKey  应用 Key
 * appId  应用Id
 * platformId 平台Id  可写为0
 * uuid  uuid
 * channel  渠道  可不传 或者为空
 * version  当前应用版本号
 * appSecret 应用秘钥
 * orientation  横竖屏  1 竖屏  0 横屏
 */

public class MainActivity extends AppCompatActivity {

    private String TAG = MainActivity.class.getCanonicalName();
    private String basePaymentDomainUrl = "http://sdk.haowanyou.com";
    private String rechargeCardUrl = "https://pf-res.haowanyou.com/m/props/rechargecardsConfig.json?v=";
    private String webRechargeUrl = "http://m.sdk.haowanyou.com";

    //支付回调
    private FtPaymentCallback ftPaymentCallback = new FtPaymentCallback() {
        @Override
        public void onPayCallback(int eventId) {
            switch (eventId) {
                case BJMGFSdkEvent.RECHARGE_SUCCESS: //充值成功
                    LogProxy.i(TAG, "recharge success");
                    break;
                case BJMGFSdkEvent.RECHARGE_FAIL: //充值失败
                    LogProxy.i(TAG, "recharge fail");
                    break;
                case BJMGFSdkEvent.RECHARGE_CANCEL: // 取消充值
                    LogProxy.d(TAG, "recharge cancel");
                    break;
                default:
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //设置日志调试打印模式，true 标识开启log打印，release 时 请移除此行代码
        FtPaymentSdk.getDefault().setDebugMode(true);


        /**
         *  标准模式 ，不启用回调 模式，目前游戏采用此模式
         */
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final  String orderNum = String.valueOf(System.currentTimeMillis());
                BaseSdkTools.getInstance().setCurrentPassPort(new PassPort());
                AppInfoBaseData appInfoBaseData = new AppInfoBaseData("0373534305a14a7287507c6eb3fefa6c","79a3877a831fdad1862ef813fc5191e6cd5f96f236c39330bd4196d2641c1a3760b9705aa72ca8f6ebfd8f8a3b3f89cba9f82ba44b08679bfecbc7c74ec718ce638efe8e69c41c8627c1df51b6d33987f756717d83f6573fdde4aaba13c52f4b77b6bf93d85bb14f","D^Yt7Jb3uiF64#xjLhy37fY^62s","50006","0","0373534305a14a7287507c6eb3fefa6c","","3.0.0","3d^7u*U72-h+fRhjB$1y",1,"123","123",false,true,"熹妃传");
                PayOrderData payOrderData = new PayOrderData(orderNum,"1008","70元宝",1,7,"088","0001","","","","","","0");
                FtPaymentSdk.getDefault().rechargeProduct(MainActivity.this, false,basePaymentDomainUrl,rechargeCardUrl,ftPaymentCallback,webRechargeUrl,appInfoBaseData,payOrderData,new PassPort());//社交平台调用接口
              // FtPaymentSdk.getDefault().rechargeProduct(MainActivity.this,String.valueOf(System.currentTimeMillis()),"1008","1000元宝",1,1000,"088","0001"); //SDK调用接口
            }
        });
        /**
         *
         *  回调模式 ，启用回调 模式，主用用于有定制化需求的应用中
         *
         */
        //设置开启支付回调模式 ，默认不开启！ 注意 ，启用支付回调选项，调用类中必须 implements(实现) FtPaymentCallback 接口，实现的onPayCallBack的方法 ，回将不同支付方式的结果回调给当前，方便调用方的个性化需求
        //由于微信支付 和 银联支付的特殊封装 ，暂无法提供回调！ 支付宝、短信、充值卡提供回调
       /* FtPaymentSdk.getDefault().setIsOpenPayCallbackMode(true);
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FtPaymentSdk.getDefault().rechargeProduct(MainActivity.this, false, "{\"uid\":\"107648051\",\"token\":\"2eda5b69881467f6b7b6ab176d8e5cd2ce59f6132dba2f93fe74a4209811465c70d204498e7b62483713a04b6d7800032f37553f687860ae3c028b2f290b3d39e8a20eb0e3977b7e33367a4763c29883b278a89fdd0f7640dde4aaba13c52f4b77b6bf93d85bb14f\",\"orderSerial\":\"54467566776766132136\",\"productId\":\"1008\",\"productName\":\"20元宝\",\"count\":\"1\",\"money\":\"7\",\"serverId\":\"088\",\"roleId\":\"0001\",\"rechargeUrl\":\"\",\"rechargeChannel\":\"0\"}",
                          "{\"appKey\":\"D^Yt7Jb3uiF64#xjLhy37fY^62s\",\"appId\":\"50006\",\"platformId\":\"0\",\"uuid\":\"f6c35274d175481c99627af5331d19ec\",\"channel\":\"\",\"version\":\"2.0.0.1922\",\"appSecret\":\"3d^7u*U72-h+fRhjB$1y\",\"orientation\":1}", ftPaymentCallback);
            }
        });
        */


    }

}
