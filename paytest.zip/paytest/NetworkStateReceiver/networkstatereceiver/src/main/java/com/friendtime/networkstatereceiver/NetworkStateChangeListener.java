package com.friendtime.networkstatereceiver;

/**
 * Created by shenliuyong on 2017/3/16.
 */

public interface NetworkStateChangeListener {
    /**
     * 网络状态监听回调
     *
     * @param currentNetworkState 当前网络状态：WiFi，Mobile @see NetworkState
     */
    void onNetworkChanged(NetworkState currentNetworkState);
}
