package com.friendtime.networkstatereceiver;

import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

/**
 * Created by shenliuyong on 2017/3/16.
 */

public enum NetworkStateHelper {
    INSTANCE;
    private NetworkStateReceiver mNetWorkStateReceiver;
    private NetworkStateChangeListener mNetworkStateChangeListener;

    /**
     * 注册
     *
     * @param context
     */
    public void registerReceiver(Context context) {
        if (mNetWorkStateReceiver == null) {
            mNetWorkStateReceiver = new NetworkStateReceiver();
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        context.registerReceiver(mNetWorkStateReceiver, intentFilter);
    }

    /**
     * 取消注册
     *
     * @param context
     */
    public void unRegisterReceiver(Context context) {
        context.unregisterReceiver(mNetWorkStateReceiver);
    }

    /**
     * 设置监听回调
     *
     * @param listener
     */
    public void setNetWorkStateChangeListener(NetworkStateChangeListener listener) {
        this.mNetworkStateChangeListener = listener;
    }

    /**
     * 获取回调
     *
     * @return
     */
    public NetworkStateChangeListener getNetworkStateChangeListener() {
        return mNetworkStateChangeListener;
    }
}
