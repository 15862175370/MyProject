package com.friendtime.networkstatereceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.util.Log;

/**
 * Created by shenliuyong on 2017/3/15.
 */

public class NetworkStateReceiver extends BroadcastReceiver {
    private static final String TAG = "NetWorkState_TAG";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "on net state changed , android.os.Build.VERSION.SDK_INT=" + android.os.Build.VERSION.SDK_INT);
        //检测API是不是小于21，因为到了API21之后getNetworkInfo(int networkType)方法被弃用
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.LOLLIPOP) {

            //获得ConnectivityManager对象
            ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

            //获取ConnectivityManager对象对应的NetworkInfo对象
            //获取WIFI连接的信息
            NetworkInfo wifiNetworkInfo = connMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            //获取移动数据连接的信息
            NetworkInfo dataNetworkInfo = connMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            checkNetworkAvailable(wifiNetworkInfo, dataNetworkInfo);
        } else {
            //这里的就不写了，前面有写，大同小异
            Log.d(TAG, "API level 大于21");
            //获得ConnectivityManager对象
            ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

            //获取所有网络连接的信息
            Network[] networks = connMgr.getAllNetworks();
            Log.d(TAG, "net works length=" + networks.length);
            //用于存放网络连接信息
            StringBuilder sb = new StringBuilder("net work state");
            //通过循环将网络信息逐个取出来

            NetworkInfo wifiNetworkInfo = null;
            NetworkInfo dataNetworkInfo = null;

            for (Network network : networks) {
                //获取ConnectivityManager对象对应的NetworkInfo对象
                NetworkInfo networkInfo = connMgr.getNetworkInfo(network);

                if (networkInfo == null) {
                    Log.d(TAG, "onReceive: networkInfo is null , break");
                    break;
                }

                sb.append(networkInfo.getTypeName())
                        .append(": connect is ").append(networkInfo.isConnected());

                switch (networkInfo.getType()) {
                    case ConnectivityManager.TYPE_WIFI:
                        Log.d(TAG, networkInfo.getTypeName() + " connect is " + networkInfo.isConnected());
                        wifiNetworkInfo = networkInfo;
                        break;
                    case ConnectivityManager.TYPE_MOBILE:
                        Log.d(TAG, networkInfo.getTypeName() + " connect is " + networkInfo.isConnected());
                        dataNetworkInfo = networkInfo;
                        break;
                }
            }
            Log.d(TAG, sb.toString());

            checkNetworkAvailable(wifiNetworkInfo, dataNetworkInfo);
        }
    }

    /**
     * @param wifiNetworkInfo
     * @param dataNetworkInfo
     */
    private void checkNetworkAvailable(NetworkInfo wifiNetworkInfo, NetworkInfo dataNetworkInfo) {
        if (NetworkStateHelper.INSTANCE.getNetworkStateChangeListener() == null) {
            Log.d(TAG, "NetworkStateChangeListener is null return !!");
            return;
        }

        //非空性判断
        if (wifiNetworkInfo == null && dataNetworkInfo == null) {
            Log.d(TAG, "WIFI为null,移动数据为null");
            NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                    .onNetworkChanged(NetworkState.WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE);
            return;
        } else if (wifiNetworkInfo == null) {
            if (dataNetworkInfo.isConnected()) {
                Log.d(TAG, "WIFI为null,移动数据可用");
                NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                        .onNetworkChanged(NetworkState.WIFI_UNAVAILABLE_MOBILE_AVAILABLE);
            } else {
                Log.d(TAG, "WIFI为null,移动数据不可用");
                NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                        .onNetworkChanged(NetworkState.WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE);
            }
            return;
        } else if (dataNetworkInfo == null) {
            if (wifiNetworkInfo.isConnected()) {
                Log.d(TAG, "WIFI可用,移动数据为null");
                NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                        .onNetworkChanged(NetworkState.WIFI_AVAILABLE_MOBILE_UNAVAILABLE);
            } else {
                Log.d(TAG, "WIFI不可用,移动数据为null");
                NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                        .onNetworkChanged(NetworkState.WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE);
            }
            return;
        }

        //检测逻辑
        if (wifiNetworkInfo.isConnected() && dataNetworkInfo.isConnected()) {
            //Toast.makeText(context, "WIFI已连接,移动数据已连接", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "WIFI已连接,移动数据已连接");
            NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                    .onNetworkChanged(NetworkState.WIFI_AVAILABLE_MOBILE_AVAILABLE);
        } else if (wifiNetworkInfo.isConnected() && !dataNetworkInfo.isConnected()) {
            // Toast.makeText(context, "WIFI已连接,移动数据已断开", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "WIFI已连接,移动数据已断开");
            NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                    .onNetworkChanged(NetworkState.WIFI_AVAILABLE_MOBILE_UNAVAILABLE);
        } else if (!wifiNetworkInfo.isConnected() && dataNetworkInfo.isConnected()) {
            // Toast.makeText(context, "WIFI已断开,移动数据已连接", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "WIFI已断开,移动数据已连接");
            NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                    .onNetworkChanged(NetworkState.WIFI_UNAVAILABLE_MOBILE_AVAILABLE);
        } else {
            // Toast.makeText(context, "WIFI已断开,移动数据已断开", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "WIFI已断开,移动数据已断开");
            NetworkStateHelper.INSTANCE.getNetworkStateChangeListener()
                    .onNetworkChanged(NetworkState.WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE);
        }
    }
}
