package com.friendtime.networkstatereceiver;

/**
 * Created by shenliuyong on 2017/3/16.
 */

public enum NetworkState {
    /**
     * WIFI 不可用，MOBILE 不可用
     */
    WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE,

    /**
     * WIFI 不可用，MOBILE 可用
     */
    WIFI_UNAVAILABLE_MOBILE_AVAILABLE,

    /**
     * WIFI 可用，MOBILE 不可用
     */
    WIFI_AVAILABLE_MOBILE_UNAVAILABLE,

    /**
     * WIFI 可用，MOBILE 可用
     */
    WIFI_AVAILABLE_MOBILE_AVAILABLE;
}
