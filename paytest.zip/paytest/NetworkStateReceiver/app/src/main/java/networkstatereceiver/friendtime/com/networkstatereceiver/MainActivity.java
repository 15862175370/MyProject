package networkstatereceiver.friendtime.com.networkstatereceiver;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.friendtime.networkstatereceiver.NetworkState;
import com.friendtime.networkstatereceiver.NetworkStateChangeListener;
import com.friendtime.networkstatereceiver.NetworkStateHelper;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NetworkStateHelper.INSTANCE.setNetWorkStateChangeListener(new NetworkStateChangeListener() {
            @Override
            public void onNetworkChanged(NetworkState currentNetworkState) {
                switch (currentNetworkState) {
                    case WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE:
                        Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                        break;
                    case WIFI_UNAVAILABLE_MOBILE_AVAILABLE:
                        Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                        break;
                    case WIFI_AVAILABLE_MOBILE_UNAVAILABLE:
                        Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                        break;
                    case WIFI_AVAILABLE_MOBILE_AVAILABLE:
                        Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                        break;
                    default:
                        break;
                }
            }
        });
    }


    @Override
    public void onResume() {
        super.onResume();
        NetworkStateHelper.INSTANCE.registerReceiver(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        NetworkStateHelper.INSTANCE.unRegisterReceiver(this);
    }
}
