# NetworkStateReceiver

## 权限

```xml
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.INTERNET" />
```

## 使用

```java
private static final String TAG = "MainActivity";

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    NetworkStateHelper.INSTANCE.setNetWorkStateChangeListener(new NetworkStateChangeListener() {
        @Override
        public void onNetworkChanged(NetworkState currentNetworkState) {
            switch (currentNetworkState) {
                case WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE:
                    Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                    break;
                case WIFI_UNAVAILABLE_MOBILE_AVAILABLE:
                    Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                    break;
                case WIFI_AVAILABLE_MOBILE_UNAVAILABLE:
                    Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                    break;
                case WIFI_AVAILABLE_MOBILE_AVAILABLE:
                    Log.d(TAG, "WIFI_UNAVAILABLE_MOBILE_UNAVAILABLE");
                    break;
                default:
                    break;
            }
        }
    });
}

@Override
public void onResume() {
    super.onResume();
    NetworkStateHelper.INSTANCE.registerReceiver(this);
}

@Override
protected void onPause() {
    super.onPause();
    NetworkStateHelper.INSTANCE.unRegisterReceiver(this);
}
```

## 静态注册

```java
<receiver android:name="com.friendtime.networkstatereceiver.NetworkStateReceiver">
    <intent-filter>
        <action android:name="android.net.conn.CONNECTIVITY_CHANGE" />
    </intent-filter>
</receiver>
```

## 依赖

```
compile 'com.friendtimes.sdk:ft_networkstatereceiver:1.0.0'
```