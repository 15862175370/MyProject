package org.bojoy.wxpay.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


public class PayReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		String name = intent.getExtras().getString("name");
		LogUtils.i("BJMEngine", "name = " + name);
	}

}
