package org.bojoy.wxpay.util;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * loading框工具类
 *
 * @author sunhaoyang
 */
public class ProgressUtil {

	protected static Dialog mProgressDialog;

	public static void showProgressDialog(Context context) {
		if (mProgressDialog != null) {// 关闭之前的loading框
			mProgressDialog.dismiss();
			mProgressDialog = null;
		} else {
			mProgressDialog = createTransparentProgressDialog(context, "加载中");
			mProgressDialog.show();
		}
	}

	public static void dismiss() {
		if (mProgressDialog != null) {
			mProgressDialog.dismiss();
		}
	}

	private static Dialog createTransparentProgressDialog(Context context,
														  String message) {
		Dialog dialog = new Dialog(context);
		dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
		LinearLayout viewGroup = new LinearLayout(context);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		viewGroup.setBackgroundColor(0x10000000);
		viewGroup.setLayoutParams(params);
		viewGroup.setPadding(10, 10, 20, 10);
		viewGroup.setOrientation(LinearLayout.HORIZONTAL);
		ProgressBar bar = new ProgressBar(context);
		TextView msgText = new TextView(context);
		msgText.setTextColor(Color.WHITE);
		msgText.setText(message);
		msgText.setGravity(Gravity.CENTER_VERTICAL);
		viewGroup.addView(bar, params);
		params.height = LayoutParams.FILL_PARENT;
		params.leftMargin = 10;
		viewGroup.addView(msgText, params);
		dialog.setContentView(viewGroup);
		dialog.setCancelable(false);
		return dialog;
	}

}
