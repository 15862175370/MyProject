package org.bojoy.wxpay.util;

import android.util.Log;

/**
 * @author liwei002
 *         LogUtils Log类，用于控制调试信息
 */

public class LogUtils {

	private static final String TAG = LogUtils.class.getSimpleName();
	//debug日志开关控制
	private static boolean isDebug = true;
	//扩展名
	private static String prefixName = "";

	public static void setDebugMode(boolean debug) {
		isDebug = debug;
	}

	public static void setPrefixName(String prefixName) {
		LogUtils.prefixName = prefixName;
	}

	public static void d(String tag, String msg) {
		if (isDebug) {
			Log.d(getLogTag(tag), msg);
		}
	}

	public static void e(String tag, String msg) {
		if (isDebug) {
			Log.e(getLogTag(tag), msg);
		}
	}

	public static void i(String tag, String msg) {
		if (isDebug) {
			Log.i(getLogTag(tag), msg);
		}
	}

	public static void w(String tag, String msg) {
		if (isDebug) {
			Log.w(getLogTag(tag), msg);
		}
	}

	private static String getLogTag(String tag) {
		return String.format("%s[%s]", prefixName, tag);
	}


}
