package com.GF.platform.wx.pay;

import android.app.Activity;
import android.os.Bundle;

import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import net.sourceforge.simcpux.Constants;
import net.sourceforge.simcpux.MD5;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.bojoy.wxpay.util.LogUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class PayActivity extends Activity {

	/**
	 * 微信支付sdk接入需要三个步骤
	 * 1.注册APPID
	 * 2.调起支付界面
	 * 3.支付结果回调
	 */

	private static final String TAG = PayActivity.class.getSimpleName();

	private IWXAPI msgApi = null;
	private String order = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (getIntent().getExtras() != null) {
			order = getIntent().getExtras().getString("payorder");
		}
		//注册APPID
		registerAppid();
		//调起微信支付界面
		genPayReq();
	}

	//生成签名字符串
	private String genAppSign(List<NameValuePair> params) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < params.size(); i++) {
			sb.append(params.get(i).getName());
			sb.append('=');
			sb.append(params.get(i).getValue());
			sb.append('&');
		}
		sb.append("key=");
		sb.append(Constants.API_KEY);

		String appSign = MD5.getMessageDigest(sb.toString().getBytes())
				.toUpperCase();
		LogUtils.e("orion", appSign);
		return appSign;
	}

	//生成随机字符串
	private String genNonceStr() {
		Random random = new Random();
		return MD5.getMessageDigest(String.valueOf(random.nextInt(10000))
				.getBytes());
	}


	//将毫秒数转化成秒数
	private long genTimeStamp() {
		return System.currentTimeMillis() / 1000;
	}

	/**
	 * 1.注册APPID
	 */
	private void registerAppid() {
		msgApi = WXAPIFactory.createWXAPI(this, null);//商户APP工程中引入微信JAR包，调用API前，需要先向微信注册您的APPID
		msgApi.registerApp(Constants.APP_ID);// 将该app注册到微信
	}

	/**
	 * 2.调起微信支付界面
	 */
	private void genPayReq() {
		LogUtils.i(TAG, "pay order = " + order);
		PayReq req = new PayReq();
		req.appId = Constants.APP_ID;//微信开放平台审核通过的应用APPID
		req.partnerId = Constants.MCH_ID;//微信支付分配的商户号
		req.prepayId = order;//微信返回的支付交易会话ID
		req.packageValue = "Sign=WXPay";//暂填写固定值Sign=WXPay
		req.nonceStr = genNonceStr();//随机字符串，不长于32位。推荐随机数生成算法
		req.timeStamp = String.valueOf(genTimeStamp());//时间戳
		List<NameValuePair> signParams = new LinkedList<NameValuePair>();
		signParams.add(new BasicNameValuePair("appid", req.appId));
		signParams.add(new BasicNameValuePair("noncestr", req.nonceStr));
		signParams.add(new BasicNameValuePair("package", req.packageValue));
		signParams.add(new BasicNameValuePair("partnerid", req.partnerId));
		signParams.add(new BasicNameValuePair("prepayid", req.prepayId));
		signParams.add(new BasicNameValuePair("timestamp", req.timeStamp));
		req.sign = genAppSign(signParams);//签名
		msgApi.registerApp(Constants.APP_ID);
		msgApi.sendReq(req);
		finish();
	}


}
