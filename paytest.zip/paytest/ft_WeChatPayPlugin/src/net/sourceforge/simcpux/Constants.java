package net.sourceforge.simcpux;

public class Constants {

	// appid
	// 请同时修改 androidmanifest.xml里面，.PayActivityd里的属性<data
	// android:scheme="wxb4ba3c02aa476ea1"/>为新设置的appid
	public static final String APP_ID = "wx9f748b9d27fb4c29";

	// 商户号
	public static final String MCH_ID = "1267457201";

	// API密钥，在商户平台设置
	public static final String API_KEY = "3ac1182cbc7acbb4b72a3b3e0b0f5f5b";
	//支付成功
	public static final String PAY_SUCCESS = "0";
	//支付成功
	public static final String PAY_FAIL = "-1";
	//支付成功
	public static final String PAY_CANCEL = "-2";


}
