package com.friendtimes.bjm_http.utils;

/**
 * Created by wutao on 2016/2/1.
 */
public class Exceptions {

    public static void illegalArgument(String msg) {
        throw new IllegalArgumentException(msg);
    }
}
