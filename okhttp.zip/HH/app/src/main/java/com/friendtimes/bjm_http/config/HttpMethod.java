package com.friendtimes.bjm_http.config;

/**
 * Created by wutao on 2015/11/26.
 * 请求方式枚举，现主要包括post、get,poststring
 */
public enum HttpMethod {
    POST, GET,POSTSTRING;
}